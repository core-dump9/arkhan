#include<stdio.h>
#include<common.h>

void main()//This here program tests out the getKey() function, F1 to quit, and some samples are included
{
	int i;
	int done;
	
    done=FALSE;
    
	
	while(!done)
	{
		i=getKey();
		switch(i)
			{
				case UPKEY:
					printf("Up arrow\n");
					break;
				case DOWNKEY:
					printf("Down arrow\n");
					break;
				case LEFTKEY:
					printf("Left arrow\n");
					break;
				case RIGHTKEY:
					printf("Right arrow\n");
					break;
				case F1:
					done=TRUE;
					break;
				default:
					printf("%i\n",i);
			}
    }
}