///////////////////////////////////////////////////////
//  Name: Getpass.h									 //
//  Creator: Thomas Grimes							 //
//													 //
//	Desc.-> This header file will accept keyboard in //
//			put but will not show the character on   //
//			the screen, only '*'.                    //
//													 //
//  Here is the syntax:                              //
//		char *<variable> = getpass("<prompt>");      //
//	Then use: strcmp(<variable>, "<password>");      //
//  to see if the <variable> = <password>.		     //
//  String.h is needed for strcmp, but strcmp is     //
//	optional.										 //
/////////////////////////////////////////////////////// 
#ifndef GETPASS_H
#define GETPASS_H

#include <stdio.h>
#include <conio.h>

#define BACKSPACE  8
#define RETURN     13

char *getpass(const char *prompt)
{
	static char buffer[128];
	int i = 0;
	char letter = NULL, ch = NULL;
		
	//cout << prompt;  //cout wont work right w/ getch() ????
	printf("%s", prompt); //Good ol' reg. C functions :) 
	while((i < 128) && (letter != RETURN))
	{
		letter = getch();
		if(letter == BACKSPACE)
		{
			if(i > 0)
			{
				buffer[--i] = NULL;
				putchar(BACKSPACE);
				putchar(' ');
				putchar(BACKSPACE);
			}
		}
		else if(letter != RETURN)
		{
			buffer[i++] = letter;
			putchar('*');
		}

	}
	
	return(buffer);
}
#endif





		