//Common.h: Common formulas, procedures, etc..
////////////////////////////////////////////////////////////////////
//This is the freeware version 1.0
////////////////////////////////////////////////////////////////////
//		Included in the zipfile:
//ShelbyWorks Graphics Library V1.0 -- It's pretty nice, look it over
//Waveplay routine by Steven H. Don -- Pretty in depth and complicated
//Getpass.h by Thomas Grimes -- Password routine that only shows ***** when password is entered
//		None of these are related to this product, or to me
////////////////////////////////////////////////////////////////////////
//Made by Matt Selnekovic  instar@rocketmail.com <-Feel free to send bug reports, etc.
//You MUST prototype the functions
//Good idea to print this out so you don't have to look it up each time
//This code was tested on Microsoft Visual C++, version 1.0 
/////////////////////////////////////////////////////////////////////////
//Visit my homepage which has nothing to do with programming, but oh well updates are coming sometime this millenia
//http://www.geocities.com/southbeach/lagoon/8410/index.html
/////////////////////////////////////////////////////////////////////////
//Sorry if the coding style varies slightly, I'm trying to get a consistant style, but it takes time  It is readable (to me) enough that I can make sense of it
/////////////////////////////////////////////////////////////////////////
//Yes, I know that many of these are implemented in some headers included with compilers already, but most are compiler specific and lots are macros, so I think that this will help clear some of it up
/////////////////////////////////////////////////////////////////////////
#include<stdlib.h>
#include<time.h>
#include<dos.h>
#include<ctype.h>
#include<conio.h>
#include"getpass.h"		//Make sure to put getpass.h and this file in the same directory, so this will work, or you could be like me and put all these files in the \include directory (cause I can never remember to put <>'s or ""'s)
#include<string.h>

////////////////////////////////
//Define PI to be 3.141592, and also define the function keys so they can be used in programs easily
//Use the F1 - F10 shortcuts with the getKey() function

#define PI 3.141592
#define F1 0x3b00
#define F2 0x3c00
#define F3 0x3d00
#define F4 0x3e00
#define F5 0x3f00
#define F6 0x4000
#define F7 0x4100
#define F8 0x4200
#define F9 0x4300
#define F10 0x4400
#define TRUE 1			//True is 1
#define FALSE (!TRUE)	//False is not 1 or 0
#define COLS 80			//DOS screen columns
#define ROWS 25			//DOS screen rows
#define VIDEO 0x10		//Video interrupt
#define KEYBOARD 0x16	//Keyboard interrupt
#define MODE_13H 0x13 	//VGA 320x200x256
#define TEXT_MODE 0x03 	//Default Text Mode
#define SCREEN_WIDTH 320//Graphics information
#define SCREEN_HEIGHT 200
#define PALETTE_MASK 0x3C6
#define PALETTE_REGISTER_RD 0x3C7
#define PALETTE_REGISTER_WR 0x3C8
#define PALETTE_DATA 0x3C9
#define UPKEY 18432		//Define UPKEY as 18432 to be used with getKey returning an integer
#define DOWNKEY 20480	//Downkey is 20480 with getKey
#define LEFTKEY 19200	//Left is 19200
#define RIGHTKEY 19712	//Right is 19712
#define ESC 283			//Escape is 283

//Common typedefs for data types, good for short quick access to commonly used variables
typedef unsigned char	    BYTE;	//Unsigned char is a BYTE
typedef unsigned short      WORD;	//Unsigned short integer is a WORD
typedef unsigned long       DWORD;	//Unsigned long integer is a DWORD
typedef int		    		BOOL;	//Integer is a BOOL
typedef unsigned int 		UINT;	//Unsigned integer is a UINT

///////////////////
//The Prototypes //
///////////////////
int square(int x);
int cube(int x);
float xToYth(int x, int y);
int maximum(int x,int y);
int minimum(int x, int y);
int rnd(int range);
int random(int range);
void pause(int delayp);
void doDOS(char *command);
void locate(int col, int row);
void cls(void);
int getKey(void);
int yorn(void);
void microDelay (long microSecs);
void milliDelay (long milliSecs);
void secDelay(long secs);
void minDelay(long mins);
void upperString(char *pS);
void lowerString(char *pS);
int password(char *prompt, char *pword);
float areaOfCircle(int r);
float circumference(int r);
float regionOfCircle(int r, int m);
float lengthOfArc(int r, int m);
float areaOfTriangle(int h, int b);
int areaOfRect(int l, int w);
float areaOfTrap(int h, int t, int b);
float areaOfQuadPD(int d, int e);
float areaOfPoly(int p, int t);
int volumeOfRect(int h, int w, int l);
int volumeOfPrism(int b, int h);
float volumeOfPyramid(int b, int h);
float volumeOfCylinder(int r, int h);
float volumeOfCone(int r, int h);
float volumeOfSphere(int r);

//////////////////////////////////////
//	M A T H  F U N C T I O N S 	    //
//////////////////////////////////////

int square(int x)//Squares an int
{
	x*=x;
	return(x);
}

int cube(int x)//Cubes an int
{
	x=x*x*x;
	return(x);
}

float xToYth(int x, int y)	//Stands for x to yth power
{
	int i=0;	//loop counter
	int b=x;
	if(y==0)		
		return(1);	//If y is zero then return 1 (special case of powers)
	if(y==1)
		return(x);	//If y is one then return the x (another special case)
	if(y==-1)
		return(1/x);	//If y is negative one then return 1/x (another special case)
	if(y<0)			//If y is less than -1, then you must put 1 over x to yth
	{
		i--;
		while(i>y)
		{
			i--;
			x*=b;
		}
		return((float)1/x);
	}	
	if(y>0)			//Regular x to yth number
	{
		i++;
		while(i<y)
		{
			i++;
			x*=b;
		}
		return(x);
	}
	return(0);		//Return 0 if nothing above works(actually, all numbers work out, but the C++ compilier(mine) says that it doesn't have a default handler or something)
}

int maximum(int x,int y)//find larger number
{
	if(x==y) 
		return(0);	//Note: If this function returns a 0, then both are equal
	if(x<y) 
		x=y;
	return(x);
}

int minimum(int x, int y)//Find smaller number
{
	if(x==y)
		return(0);	//Note: If this function returns a 0, then both are equal
	if(x>y)
		x=y;
	return(x);
}

int absolute(int x)//Find absolute value (distance from zero)
{
	return(maximum(x,-x));
}

int isPos(int x)//Finds out if the number is positive, doesn't change it    use it for simple range checks
{
	if(x==0)
		return(FALSE);		//If number is 0, then it can't be either!(that's what I was taught in algebra)
	if(x>0)
		return(TRUE);
	else
		return(FALSE);
}

int isNeg(int x)//Finds out if number is negative, doesn't change it
{
	if(x==0)
		return(FALSE);		//if number is 0, then it can't be negative, its not either
	if(x<0)
		return(TRUE);
	else
		return(FALSE);
}

int toPos(int x)//Changes number to positive
{
	if(isNeg(x))
		x=-x;//Two negatives equal a postive (remember that from algebra?)
	return(x);
}

int toNeg(int x)//Changes number to negative
{
	if(isPos(x))
		x=-x;//One negative equals... you get the picture
	return(x);
}

int isEven(int x)//Finds if number is even
{
	if(x%2==0)
		return(TRUE);//If its remainder of division is 0, then it is even(return TRUE)
	else
		return(FALSE);
}

int isOdd(int x)//Finds if number is odd
{
	if(x%2==1)
		return(TRUE);
	else
		return(FALSE);
}

//////////////////////////////////////////////////////////////
//	B I O S  A N D  O T H E R  F U N C T I O N S			//
//////////////////////////////////////////////////////////////

int rnd(int range)		//Requires STDLIB.h
{
	int r;
	r=rand()%range;		//Make random number, pare it down
	return(r);
}
			
int random(int range)		//Call this function ONLY (for random numbers that is (Well, maybe  just be careful with the rnd function, it doesn't seed randomizer))
{							//needs time.h
	srand((unsigned)time(NULL));//Call timer, make unsigned, plant random seed
	return(rnd(range));			//Make random number, send to rnd() function
}

void pause(int delayp)		//This function takes in delayp*10000 to get time to wait so put in seconds or so
{
	int delay;
	delayp*=10000;
	for(delay=0;delay<delayp;delay++);	//wait loop, seems easy enough change 10000 if not long enough
}

void doDOS(char *command)	//This works in DOS programs, Windows programs might be messed up
{
	system(command);		//Needs stdlib.h, simple enough
	getch();				//Wait here until key pressed
}

void locate(int col, int row)//Locate cursor at location on screen, also use in DOS programs only
{							 
	union REGS regs;
	
	regs.h.ah=0x02;
	regs.h.bh=0x00;
	regs.h.dh=row;
	regs.h.dl=col;
	int86(VIDEO,&regs,&regs);
}

void cls(void)		//clear screen, same as DOS command DOS programs only
{
	union REGS regs;
	
	regs.h.ah=0x06;
	regs.h.al=0x00;
	regs.h.bh=0x07;
	regs.h.ch=0x00;
	regs.h.cl=0x00;
	regs.h.dh=ROWS-1;
	regs.h.dl=COLS-1;
	int86(VIDEO,&regs,&regs);
	
	locate(0,0);	//Home cursor
}                                                         
	
int getKey(void)	//Reads keyboard for input, returns integer scancode  (For function keys, and combinations (shift, alt, control etc.))
{
	union REGS regs;
	
	regs.h.ah=0x00;
	int86(KEYBOARD,&regs,&regs);
	return(regs.x.ax);
}

int yorn(void)		//Gets a Y(es) or N(o) and returns TRUE for Y and FALSE for N  use it in if() statements or something
{
	int done=FALSE;
	char c;
	
	while(!done)
	{
		c=toupper(getch());
		if(c=='Y' || c=='N')
			done=TRUE;
	}
	if(c=='Y') return(TRUE);
	return(FALSE);
}	

void microDelay(long microSecs)//A much better pause or delay function for C in microseconds
{       						//Assembly code, don't try mucking with it (unless you know it)
  _asm {
    mov cx, word ptr [microSecs+2]
    mov dx, word ptr [microSecs]
    mov ah, 0x86
    int 0x15
  }
}

void milliDelay(long milliSecs)//Milliseconds pause delay
{
	microDelay(milliSecs*1000);
}	

void secDelay(long secs)//Seconds delay
{
	milliDelay(secs*1000);
}

void minDelay(long mins)//Minute delay, not that usefull, nobody wants to sit around for a minute
{
	secDelay(mins*60);
}

void upperString(char *pS)//Makes a string uppercase, takes a string
{
	while(*pS)//goes from start of string to the /0 (NULL) thing at the end 
	{
		if(islower(*pS))//If the character is lowercase...
			*pS=toupper(*pS);//Then make it uppercase and...
		pS++;	//go to the next character in the string
	}
}

void lowerString(char *pS)//Makes a string lowercase, takes a string
{
	while(*pS)
	{
		if(isupper(*pS))//Same as above(close, but reversed in key places)
			*pS=tolower(*pS);
		pS++;
	}
}

int password(char *prompt, char *pword)//This password routine takes in two strings, first, the prompt message(add a \n at the end of it), and second, the actual password
{										//This function basically simplifies the getpass function defined in getpass.h  it was given to me by Thomas Grimes, for which I thank him
	int i=strcmp(getpass(prompt),pword);//String compare what you get from getpass, and the password
	if(i==0)		//Strcmp returns three values 0 means exactly alike
		return(TRUE);//If the person types the right one, then this returns TRUE(notice I didn't display the message confirming the right password, you do that
	else
		return(FALSE);//If the bloody scalawag doesn't then return FALSE
	
}
////////////////////////////////////////////////////////////////////////
//		G E O M E T R Y  F O R M U L A S		      				  //
////////////////////////////////////////////////////////////////////////
//From here on in, I'll provide formula in comments for clarification //
//Also, in circle formulas r is radius, m is measure of degrees       //
//In triangles, h is height, b is base				                  //
//In rectangles, l is length, w is width							  //
////////////////////////////////////////////////////////////////////////
//Now you can write your own geometry program...           			  //
//Actually, this could be useful for some types of graphics			  //
////////////////////////////////////////////////////////////////////////

float areaOfCircle(int r)
{
	float a;	//area variable
	//Finds area of a circle in terms of radius r	A=PI*r*r(r squared)
	r*=r;	//R squared
	a=(float)PI*r;
	return(a);
}

float circumference(int r)
{
	float c;	//circumference variable
	//finds circumference of circle		C=2*PI*r
	c=(float)2*PI*r;
	return(c);
}

float regionOfCircle(int r, int m)
{
	float a;	//area variable
	//find area of region in circle (think pie wedge)  m/360*PI*r*r (r squared)
	a=(m/360)*(float)(PI*r*r);
	return(a);
}

float lengthOfArc(int r, int m)
{
	float l;	//length variable
	float c;	//circumference variable
				//find length of arc in circle (think pie crust)	l/c=m/360
	c=circumference(r);
	l=c*(m/360);	
	return(l);	
}

float areaOfTriangle(int h, int b)
{
	float a;	//area variable
	//finds area of triangle	1/2*b*h
	a=(float)0.5*(b*h);
	return(a);
}

int areaOfRect(int l, int w)	
{			//Note: Rectangles, squares, and parallelograms have same area formula
	int a;		
	//finds area of rectangle	l*w
	a=l*w;
	return(a);
}

float areaOfTrap(int h, int t, int b) //H is height, T is top, B is base
{
	float a=(float)0.5*h*(t+b);	//Area of trapezoid is 1/2 height times the sum of the two bases  1/2*H*(Top+Bottom)
	return(a);
}

float areaOfQuadPD(int d, int e)	//Area of quadrilateral with perpendicular diagonals d is diagonal 1, e is diagonal 2 (doesn't matter what order)
{
	float a=(float)0.5*d*e;
	return(a);
}

float areaOfPoly(int p, int t)	//Area of a regular polygon, p is perimeter, t is the apothem
{
	float a=(float)0.5*p*t;	//Area is 1/2 of perimeter times apothem
	return(a);
}

int volumeOfRect(int h, int w, int l)	//Volume of a right rectangular prism
{
	int v=h*w*l;		//Volume is height times length times width
	return(v);
}

int volumeOfPrism(int b, int h)		//Volume of generic prism, b is area of base, use above formulas to find
{
	int v=b*h;		//Volume of prism is area of base times height
	return(v);
}

float volumeOfPyramid(int b, int h)	//Volume of pyramid
{
	float v=(b*h)/3;	//Volume of pyramid is 1/3 area of base times height 
	return(v);
}

float volumeOfCylinder(int r, int h)	//r radius of base, h height
{
	float v;
	r*=r;		//R squared
	v=(float)PI*r*h;	//Volume of cylinder is PI*r*r*h
	return(v);
}

float volumeOfCone(int r, int h)
{
	float v;
	r*=r;		//R squared
	v=(float)(PI*r*h)/3;	//Volume of cone is 1/3 of PI*r*r*h
	return(v);
}

float volumeOfSphere(int r)
{
	float x=4/3;
	float v;
	r=r*r*r;			//R cubed
	v=(float)PI*r*x;	//Volume of sphere is 4/3 PI*r*r*r
	return(v);
}
	
///////////////////////////////////////////////////////////
//Anything this or you do to your computer is not my fault.

///////////////////////////////////////////////////////////
//COPYRIGHT INFORMATION
//This source code can be used by any person in their own programs for free.  The Author of this source code allows anyone to freely use this as they please in their own programs.  
//DOS is a copyright of Microsoft.  Other copyrights are trademarks of their respective owners.
//Copying this for commercial sale, exploitation, or any other uses not implied here is not allowed.
