#include <go32.h>
#include <stdio.h>
#include <sys/farptr.h>

int main(void)
{
  unsigned char c;
  c = _farpeekb(_dos_ds, 1047);
  _farpokeb(_dos_ds, 1047, c | 64);
  return 0;
}
