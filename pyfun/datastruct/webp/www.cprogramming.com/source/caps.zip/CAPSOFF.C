void main(){ *(char far *)1047 &= 191; }
