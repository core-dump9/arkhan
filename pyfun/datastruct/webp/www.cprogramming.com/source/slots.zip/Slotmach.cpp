/* Slot Machine Program by Joe Tchamitchian*/
// OOP additions to slot machine by Mike Mackrory - August 8, 2001

#include "A:\slotmach.hpp"

void main()
{
	SlotMachine Slot;
	Slot.SetTokens(40);
	Slot.StartScreen();
	Slot.PlaySlots();
}
