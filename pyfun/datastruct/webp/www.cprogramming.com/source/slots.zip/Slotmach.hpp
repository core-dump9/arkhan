#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <iostream.h>
#include <dos.h>
#include <string.h>

class SlotMachine
{
	public:
		// constructor
		SlotMachine() {};
		//destructor
		~SlotMachine() {};
		//functions
		void StartScreen();
		void PlaySlots();
		void PullLever() {LeverPulling();}
		void ShowMachine();
		//accessor functions
		int GetTokens() {return numTokens;}
		void SetTokens(int tokens) { numTokens = tokens; }

	private:
		static int numTokens; //keeps track of tokens
		void LeverPulling(); //simulates a handle being pulled
		void Spin(); //acts as delay and selects numbers
		void Result(); //determines result of lever pull
		int numA;
		int numB;
		int numC;
};

int SlotMachine::numTokens = 0;

void SlotMachine::StartScreen()
{
	textcolor(LIGHTRED);
	textbackground(BLACK);
	clrscr();
	gotoxy(12,5);
	cprintf("********************************************************");
	gotoxy(12,6);
	cprintf("*             Welcome to the slot machine.             *");
	gotoxy(12,7);
	cprintf("*               Press any key to play..                *");
	gotoxy(12,8);
	cprintf("********************************************************");
	getch();
}

void SlotMachine::PlaySlots()
{
	//initialize variables
	SlotMachine Slot;
	int play	= 1;
	int cont = 0;
	randomize();
	//Play the slots
	textcolor(WHITE);
	textbackground(BLUE);
	clrscr();
	int tokens = Slot.GetTokens();

	while(play == 1)
	{
		textcolor(YELLOW);
		gotoxy(33,1);
		cprintf("SLOT MACHINE");
		gotoxy(33,2);
		cprintf("$$$$$$$$$$$$");
		textcolor(WHITE);
		textbackground(BLUE);

		gotoxy(30,5);
		cprintf("You have %d tokens.",tokens);

		Slot.ShowMachine();

		textcolor(LIGHTGREEN);
		gotoxy(25,18);
		cprintf("Press any key to pull handle...");

		textcolor(GREEN);
		gotoxy(26,23);
		cprintf("Press Q to quit at any time");

		cont = getch();

		if(cont == 'Q' || cont == 'q')
			play = 2;
		else
			Slot.PullLever();
		tokens = Slot.GetTokens();
		if(tokens <= 0)
			play = 2;
	}
	// exit
	textbackground(BLACK);
	clrscr();
	textcolor(LIGHTBLUE);
	gotoxy(20,5);
	cprintf("Thank-you for playing \"The Slot Machine\".");
	gotoxy(20,6);
	cprintf("You are leaving with %d tokens.",tokens);
	gotoxy(30,10);
	textcolor(LIGHTRED);
	cprintf("GOOD-BYE!");
	getch();
}

void SlotMachine::ShowMachine()
{
	textcolor(WHITE);
	unsigned char side = 176;
	for(int t = 20; t <=60; t++)
	{
		gotoxy(t,7);
		cprintf("%c",side);
	}
	gotoxy(20,8); cprintf("%c",side);
	gotoxy(20,9); cprintf("%c",side);
	gotoxy(20,10); cprintf("%c",side);
	gotoxy(60,8); cprintf("%c",side);
	gotoxy(60,9); cprintf("%c",side);
	gotoxy(60,10); cprintf("%c",side);
	for(int b = 20; b <=60; b++)
	{
		gotoxy(b,11);
		cprintf("%c",side);
	}
	for(int h = 2; h <= 11; h++)
	{
		gotoxy(62,h);
		cprintf("%c",side);
	}
	gotoxy(61,11); cprintf("%c",side);
}

void SlotMachine::LeverPulling()
{
	unsigned char side = 176;
	textcolor(BLUE);
	gotoxy(30,13);
	cprintf("                  ");
	for(int h = 2; h < 10; h++)
	{
		textcolor(BLUE);
		gotoxy(62,h);
		cprintf("%c",side);
		gotoxy(79,23);

		Spin();
	}
	for(h = 9; h >= 2; h--)
	{
		textcolor(WHITE);
		gotoxy(62,h);
		cprintf("%c",side);
		gotoxy(79,23);
		Spin();
	}
	Result();
}

void SlotMachine::Spin()
{
	numA = random(10)+1;
	numB = random(10)+1;
	numC = random(10)+1;
	textcolor(BLUE);
	gotoxy(30,9);
	cprintf("%d",11);
	gotoxy(40,9);
	cprintf("%d",11);
	gotoxy(50,9);
	cprintf("%d",11);

	textcolor(LIGHTRED);
	gotoxy(30,9);
	cprintf("%d",numA);
	gotoxy(40,9);
	cprintf("%d",numB);
	gotoxy(50,9);
	cprintf("%d",numC);
	delay(125);
}

void SlotMachine::Result()
{
	int got = 0;
	char threeInARow[] = "Three in a row!!!";
	char twoTheSame[] = "Pair!!";
	char youLose[] = "Sorry, try again.";
	char msg[18] = "";

	if(numA==numB && numB==numC)
	{
		strcpy(msg, threeInARow);
		numTokens+=4;
		got = 1;
	}
	if(got == 0)
		if(numA==numB ||
			numA==numC ||
			numB==numC)
		{
			strcpy(msg, twoTheSame);
			numTokens++;
			got = 1;
		}
		else
		{
			strcpy(msg, youLose);
			numTokens--;
		}

	textcolor(WHITE);
	int dist = (80-strlen(msg))/2;
	gotoxy(dist, 13);
	cprintf("%s", msg);
}

