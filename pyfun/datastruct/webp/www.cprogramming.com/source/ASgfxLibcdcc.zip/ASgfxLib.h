
//GFX LIB

#include <fstream.h>
#include <dos.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream.h>
#include <bios.h>
#include <sys/nearptr.h>
#include <mem.h>


#define mode_13h 0x13
#define mode_text 0x03


//external vars

//FOR DJGPP DIRECT GRAPHICS
#define   djgpp_gfx_init                                    {   \
if (__djgpp_nearptr_enable() == 0)                              \
  exit(-1);                                                     \
                                                                \
VGA=(byte *)(0xa0000 + __djgpp_conventional_base);              \
my_clock=(word *)(0x0046c + __djgpp_conventional_base);    }    \

#define djgpp_gfx_exit  __djgpp_nearptr_disable();
//********
#define true 0
#define false -1


#define mode_13h 0x13
#define mode_text 0x03

//***************************************************************************

//for graphics... (and clock(for ran))
typedef unsigned char  byte;
typedef unsigned short word;


byte *VGA=(byte *)0xA0000000L;        /* this points to video memory. */
word *my_clock=(word *)0x0000046C;    /* this points to the 18.2hz system
                                         clock. */


#define randomize srand(*my_clock);


int buf;
//prototypes
void set_mode(int mode);
inline int put_pixel(register int x, register int y, register  int c);
inline int get_pixel(register int x, register int y);
inline int ran_num(register int min,register  int max);


//inline funcs
inline int get_pixel(register int x,register int y) {return VGA[(y<<8)+(y<<6)+x];}
inline int put_pixel(register int x, register int y, register  int c){VGA[(y<<8)+(y<<6)+x]=c;}
inline int ran_num(register int min,register  int max){buf=rand()%(max+1-min);buf+=min;return buf;}


//non inline
void set_mode(int mode){

union REGS regs;
regs.h.ah=0x00;
regs.h.al=mode;
int86(0x10,&regs,&regs);
return;
}








