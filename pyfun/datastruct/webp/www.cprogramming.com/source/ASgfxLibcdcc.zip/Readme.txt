*************************AwdSoft GFX Library*********************************
*Programmer:	ANDY DAVENPORT (Loel@Mindspring.com)
*Ver:		1.0 Alpha, 1999
*Liscence:	Public Domain 
*****************************************************************************


Table of Contents
-----------------
DISCLAIMRE
1. Introduction
2. How to use
3. Functions
4. Liscence
5. Contact
6. Getting DGJPP
7. Plans for Future Verisons
----------

----------------------------------------------------------------------------
email me: awdsoft16@hotmail.com
----------------------------------------------------------------------------

				DISCLAIMER
THE standard, IF THIS DOES ANYTHING HARMFUL TO YOUR COMPUTER ITS NOT MY 
FAULT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	by using this in any way, you agree to this...

				1. INTRODUCTION
-----------------------------------------------------------------------------
	AwdSoft (R) 
AwdSoft GFX Library is a graphics add on for C\C++ written using DJGPP
If you want to use it with DJGPP simply put init_djgpp_gfx BEFORE using any 
graphics functions.  WITHOUT that code, you can use it with other compilers.
I ask nothing but a name in the credits and an email to "AwdSoft16@hotmail.com"
with the description of what  you made with it, and <maybe> a free copy...
if you are generous.  




				2. How to Use
-----------------------------------------------------------------------------
IN YOU PROGRAM:
simply add this to the begining of you file:
#include "ASgfxLib.h" //(if you put the header file in the director of your program  OR
//---OR----
#include <ASgfxLib.h> //(if you put the header file in the standard include directory

				3. FUNCTIONS
----------------------------------------------------------------------------
djgpp_gfx_init
----------------
				DESCRIPTION
a macro that exits DJGPP's protected mode and allows graphics and direct VGA
memory access.  
Use this BEFORE any graphics functions are used (IF YOU ARE USING "DJGPP"),
otherwise, DON'T put this in.
				SYNTAX
NO arguments.  Simply put...
djgpp_gfx_init;			
				EXAMPLE
int main() {
djgpp_gfx_init;   //you are now  ready to use putpixel\getpixel for DJGPP
		  //reste of code
return 0;
}


djgpp_gfx_exit
---------------
				DESCRIPTION
a macro that undoes the affects of "djgpp_gfx_init"
Re-Enters protected mode (no more direct VGA access)
use this under DJGPP if you called "djgpp_gfx_init"
***Remember to call this after all graphics or done or when the program ends
				SYNTAX
NO ARGUMENTS; 
djgpp_gfx_exit;
								EXAMPLE
int main() {
//CODE HERE (put djgpp_gfx_init first)

djgpp_gfx_exit;   //after done w\ gfx or prog exits
return 0;
}



put_pixel
-----------
				DISCRIPTION
A void function that returns nothing.  Plots a pixel (quickly) using
direct VGA memory access.  
				SYNTAX
put_pixel(int X, int Y, int C);
ARGUMENTS:
X- X cordinant of the pixel
Y- Y cordinant of the pixel
C- Color of the pixel (a number)
				EXAMPLE
int main(){
init_djgpp_gfx;  //so you can use it!
put_pixel(1, 5, 2); //plots a green (2) at (1, 5)

exit_djgpp_gfx;	   //all done
return 0;
}				


get_pixel
-----------------				
				DESCRIPTION
an int function that returns the color of the pixel at a specified place
uses direct VGA memory access
				SYNTAX
int C=get_pixel(int X, int Y);
ARGUMENTS:
X- X cord of pixel color to be returned
Y- Y cord of pixel color to be returned
				EXAMPLE
int main(){
int c; 			//buffer to use to get the color

init_awdsoft_gfx; //so you can use it!
c=get_pixel(100, 100);//c will now equal the color of the pixel at (100, 100)

exit_awdsoft_gfx; //all done!
return 0;
}

				
randomize
----------
				DESCRIPTION
a macro that seeds the random # generator with the value in the clock
call this before you call ran_num(min, max);
				SYNTAX
NO ARGUMENTS:
randomize;
				EXAMPLE
int main{
int random_number;
//no need for init_awdsoft_gfx b\c no gfx functions are used
randomize;
//you can now use ran_num

return 0;
}


ran_num
-------
				DESCRIPTION
an int function that returns a random number between min and max (including min and max)
*note* if you don't call randomize first, it will ask the use for a "seed"

				SYNTAX
int r=ran_num(int min, int max);
ARGUMENTS:
min- the minimum # to be returned
max- the maximum # to be returned
				EXAMPLE
int main{
int random_number;
//no need for init_awdsoft_gfx b\c no gfx functions are used
randomize;
//you can now use ran_num
random_number=ran_num(101, 200);  //random_number now is anywhere from
				  //101-200
return 0;
}


ONE LAST THING-*my_clock
---------------------------
*this lib creates a global pointer variable called "my_clock"
it always points to clock
if you need a pointer to the clock... just set!

float current_clock=my_clock;



					4. LISENCE
----------------------------------------------------------------------------
FREE, PUBLIC DOMAIN.
ALL I ASK IS CREDITS IN YOUR PROGRAM AND AN EMAIL TELLING THAT YOU USED IT, AND
MAYBE A FREE COPY OF YOU PROGRAM


					
					5. CONTACT
----------------------------------------------------------------------------
AwdSoft16@hotmail.com

					6. GETTING DJGPP
----------------------------------------------------------------------------
www.delorie.com/djgpp
from there goto "ZIP PICKER"


					7. PLANS FOR FUTURE VERSIONS
----------------------------------------------------------------------------
1. Soup up current routings with ASMEMBALLY
2. 3d polygons
3. Pallete
4. BITMAPS (all extensions)
5. Mouse
6. A BASIC VERSION OF THE LIB (for QB45 and VBDOS)





