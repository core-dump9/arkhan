//*************************************
//***************B*I*N*O***************
//*************************************
//*******Base Conversion Algorithm*******
//Programmer/Engineer: Ryan Lloyd
//Project Name: "bino"
//Date Started: 10-25-00
//Date of Completion: 10-30-00
//Course: Advanced Placement Computer Science
//Teacher: Mr. Swanson
//Period: Six

//Visit Wonder Workers' C++ / C / Quick BASIC Site:
//		http://www.geocities.com/wonworkers/main.html

//Feel free to e-mail Wonder Workers, Inc. at:
//		wonderworkers@excite.com



#include <iostream.h>
#include <conio.h>
#include <iomanip.h>
#include <math.h>

int main()
	{
   int cotinue=1;
   long int org_num=0, org_base=0, valid_org_val, pos_org_num, new_num, base10_num, remainder;
   int new_base=0;
   int pow_limit, pow_test;
   int cur_term=0;
   cout<<setiosflags(ios::left);
   do
   	{
      //The outermost "do...while" loop allows for repetitive revolutions of
      //the primary block of the application.  The program will continue to
      //oscillate between the input and output pages as long as the variable
      //referred to as "cotinue" is equal to "1."  This variable can be changed
      //through user input at the end of the output page.
      do
      	{
         //This repetition statement ensures that the base of the initial number,
         //which is discovered by the program through a user input statement,
         //is a value between 1 and 17 exclusively.  The prompt message will
         //continue to be displayed and the user will continue to be required
         //to enter in the value of the base for the original number if he/she
         //incessently enters invalid bases into the system.
	      cout<<endl<<"Enter the base that the original number must be converted to\n"<<setw(67)<<"(the value should be between 2 and 16, inclusively).";
         cin>>new_base;
         }	while((new_base < 2) || (new_base > 16));
      do
      	{
         //This "do...while" loop will continue to run as long as the "org_num"
         //variable, which sybolizes the amount of the initial number, does not
         //meet specific requirements concerning the size of the first value.  The
         //user is expected to abide by the rules connecting the value of the
         //new base and the amount of the number that must be converted,
         //which are explained to the operator during the execution of the project
         //with the aid of the "cout" statement below.  If the first amount is too
         //large or too small (in terms of a negative value) to be converted
         //into the specified base, the user will be required to enter in a new
         //number which fits the parameters for the new base.
	      cout<<"\n\nInput the integer that must be converted.\n\nIf the new base is 2, then the original number must be\ngreater than or equal to -1,000 and less than or equal to 1,000.\n\nIf the new base is > 2 and < 11, then the initial number\nshould be between -10,000 and 10,000, inclusively.\n\nWhen the new base is larger than 10, the number\n"<<setw(67)<<"must be between -1,000,000 and 1,000,000, inclusively.";
   	   cin>>org_num;
         }	while((((org_num < -1000) || (org_num > 1000)) && (new_base == 2)) || (((org_num < -10000) || (org_num > 10000)) && ((new_base > 2) && (new_base < 11))) || (((org_num < -1000000) || (org_num > 1000000)) && (new_base > 10)));
      cout<<endl;
      do
       	{
         //The nested "do...while" repetition statement will repeat as long as
         //the original base of the original integer is less than 2 or greater
         //than 10.  Since the variable of "org_num," which stores the initial
         //whole number, is an integer, the base of the first number cannot exceed
         //10.  If the base was allowed to exceed 10, then letters and other
         //nonnumerical characters would be allowed as input into the "org_num"
         //integer identifier, effectively breaking C++ syntax rules.  Similar
         //to the two previous "do...while" loops, this repetition unit will
         //continue to execute with a prompt for user input continually being
         //displayed on the monitor while the base of the starting whole number
         //is less than 2 or larger than 10.   
	      cout<<"\nWhat is the base of the initial number\n"<<setw(67)<<"(the base should be between 2 and 10, inclusively)?";
         cin>>org_base;
         }	while((org_base < 2) || (org_base > 10));
      clrscr();					//Second Page Begins to Be Processed 
	   //***Full Conversion Process Begins Below
      if(org_num < 0)
      	//If it is discovered that the original number is negative, the initial amount
         //is transformed into a positive value by storing the product of -1 and
         //"org_num" in the identifier named "pos_org_num."
      	pos_org_num = org_num * -1;
      else
      	//If "org_num" is positive or equal to 0, the value of the first whole number
         //is placed in "pos_org_num."
      	pos_org_num = org_num;
      //**Start of Conversion to Base Ten
      for(pow_test=0; pow(10, pow_test) <= pos_org_num; ++pow_test);
      	//The above "for" loop, which does not contain a single executable statement
         //but rather serves as a counter, determines the final value of "pow_test."
         //"pow_test" is an integer variable that holds the first value "n" in
         //the expression "1 * 10^n" such that the result of the expression
         //is greater than "pos_org_num."  The final value of "pow_test" also
         //stores the number of single digits that are found in the positive
         //form of the intial number.  "pow_test" is incremented by 1 after each
         //revolution through the loop, and the repetition statement will end
         //when the result of "10^pow_test" is greater than the original amount
         //in its positive form.
      for(pow_limit=(pow_test - 1), remainder=pos_org_num, base10_num=0, valid_org_val=1; pow_limit >= 0; --pow_limit)
      	{
         //The purpose of this "for" loop involves converting the initial amount,
         //which is now present in its positive form in the variable called
         //"pos_org_num," to its equivalent value in base 10.  The identifier
         //named "pow_limit" is initialized at an upper bound--the number of
         //digits that are in "pos_org_num" subtracted by 1.  "remainder,"
         //an identifier that stores the amount within "pos_org_num" which have
         //not been subtracted by the succeeding processes, is set to the positive
         //form of "org_num."  "base10_num" is an accumulator that holds the current
         //result of the conversion process of "pos_org_num" into a base 10 value.
         //On the other hand, "valid_org_val" is initialized to 1, signifying
         //that the program assumes at first that all digits in "pos_org_num"
         //are less than the original base that the value is in.  This loop will
         //continue to execute as long as "pow_limit" is greater that -1, and
         //the value stored in "pow_limit" will decrement by 1 at the end of each
         //revolution.
         cur_term = (remainder / pow(10, pow_limit));
         //The above assignment statement allows the computer to identify any
         //digit that lies within "pos_org_num."
         if(cur_term >= org_base)
         	{
            //If the current term that is being analyzed in the "for" loop is
            //discovered to be greater than or equal to the base that the amount
            //was originally in, "pow_limit" is set to -1 (the outer "for" loop
            //will terminate when "pow_limit" is less than 0) and "valid_org_base"
            //is assigned the value of 0, signifying that the orginal value does
            //not coincide with its suggested original base.
            pow_limit=-1;
            valid_org_val=0;
            }
         base10_num = (base10_num + (cur_term * pow(org_base, pow_limit)));
         //The previous value of "base10_num" is added to the current digit that
         //was pulled from the positive form of the initial number times the result
         //of the number's original base raised to the current value of "pow_limit."
         //After the surrounding repetition statement is finished executing,
         //"base10_num" will contain the value of the original amount converted
         //into base 10 number representation.  This process is performed to
         //improve the logical pathway involved in transforming a number in any
         //base that is less than 10 into its equivalent amount in a second base
         //that is under 10.
         remainder = (remainder - (pow(10, pow_limit) * cur_term));
         //The updated version of "remainder" is found by raising 10 to the current
         //value for "pow_limit," multiplying the result by the digit that is being
         //analyzed from the intial amount, and subtracting the product from the
         //previous value of "remainder."
         }
      //**End of Base Ten Conversion
      if(valid_org_val == 0)
      	//If the original number contains digits that exceed or equal the first
         //number's base, an error message will be outputted and the program will
         //ask the operator if he/she wants to attempt the conversion stage again.
      	cout<<"\n\n\n\nError: The Base and the Value of the Original Number Do not Coincide";
      else
      	{
         //This block of code will be accessed by the computer if all of the digits
         //in the initial number are less than the base that the number is supposedly in.
         cout<<"\n\n\n\nThe conversion of "<<org_num<<" from base "<<org_base<<" to base "<<new_base<<" reads as follows:\n\n";
	      for(pow_test=0; pow(new_base, pow_test) <= base10_num; ++pow_test);
         	//Although the above "for" loop lacks a body, its heading serves as
            //a counter for the number of characters that lie within the newly
            //created "base10_num" variable.  The loop's control variable, which
            //is referred to as "pow_test," will increment by one after each run
            //through the loop, and the loop will continue to execute while the
            //result of "new_base ^ pow_test" is less than or equal to the base 10
            //conversion of the positive form of the original number.
   	   if(new_base < 11)
      		{
            //If the base that the intial value is being converted over to is
            //less than 11, then the following segment of code is performed.
	      	for(pow_limit=(pow_test-1), remainder=base10_num, new_num=0; pow_limit >= 0; --pow_limit)
    	  			{
               //The purpose of this repetition statement is to convert the newly
               //developed "base10_num" variable into the new base that was
               //specified by the user.
               //This "for" loop initializes "pow_limit," which symbolizes the digit
               //that is being reviewed within "base10_num" in terms of scientific
               //notation, to the difference of "pow_test" minus 1.  In addition,
               //"remainder," a variable that holds the amount in "base10_num"
               //that has not been subtracted from the variable's original value
               //by the following operations, is first set to equal "base10_num."
               //The sum of the conversion process of "base10_num" to the number's
               //new base is set to a starting value of 0.  The loop's control variable
               //of "pow_limit" decreases by 1 following each successful cycle of the
               //repetition statement's body, and the loop's body will continue
               //to execute as long as "pow_limit" is not less than 0.
		         cur_term = pow(new_base, pow_limit);
               //The current term or digit that will be divided by "base10_num"
               //is calculated and stored in "cur_term" by raising the original
               //integer's new base to the value of "pow_limit."
   		      new_num = new_num + (pow(10, pow_limit) * (remainder / cur_term));
               //The value of "new_num," which represents the current progress of
               //converting the original whole number to the new base, is found
               //by raising 10 to "pow_limit," multiplying the result by the outcome
               //of "remainder" divided by "cur_term," and adding the product to
               //the previous value of "new_num."
      		   remainder = (remainder - ((remainder / cur_term) * cur_term));
               //The new value of "remainder" stores the current amount residing
               //in "base10_num" which have not been "touched" by the division
               //and conversion processes.
         		}
	         if(org_num < 0)
            	//If the original amount is discovered to be negative, the positive
               //form of "new_num" will become negative by multiplying "new_num"
               //by -1.
   	   		new_num = new_num * -1;
      	   cout<<new_num;			//The user's final, highly desired conversion solution is outputted onto the screen.
         	}
	      else
   	   	{
            //If the new base is not between 2 and 10, inclusively, then an entirely
            //different process must be performed to reveal the proper answer.
            //Instead of storing the converted solution to the original number in
            //a variable, the individual characters, including letters and numbers,
            //are printed on the monitor as they are discovered.
				for(pow_limit=(pow_test-1), remainder=base10_num; pow_limit >= 0; --pow_limit)
    	  			{
               //This "for" loop is designed to calculate and display each value
               //of the conversion's solution character-by-character.  The loop's
               //control variable (or "pow_limit") is initialized at "pow_test - 1,"
               //which reveals the number of digits that exist in the number stored
               //in "base10_num."  On the other hand, "remainder" is first set to
               //equal "base10_num."  The loop's control variable decrements by 1
               //at the conclusion of each revolution through the loop, and the
               //loop will run as long as "pow_limit" is not less than 0.
	         	cur_term = pow(new_base, pow_limit);
               //The current "term" of the conversion process is calculated by
               //raising the new base to the current value for "pow_limit."  For
               //instance, if "new_base" is 6 and "pow_limit" is equivalent to
               //3, then "cur_term" equals 216.
	            if((remainder / cur_term) < 10)
               	//If the newly discovered character in the solution is a number
                  //that is less than 10, then the numerical form of the single
                  //digit is displayed on the screen with the aid of the
                  //output statement that is written below.
   	         	cout<<(remainder / cur_term);
      	      else
               	//If the new character in the problem's solution is a value
                  //which is greater than 9, then the letter form of the new number
                  //is displayed to the user.  For example, if the new element is
                  //12, the letter "C" will be displayed instead of "12."
         	   	cout<<char(65 + ((remainder / cur_term) - 10));
      	   	remainder = (remainder - ((remainder / cur_term) * cur_term));
               //The above line of code determines the new value of "remainder,"
               //which contains the amount of "base10_num" that has not been affected
               //by the program.
	         	}
   	      }
      	}
      //***End of Full Base Conversion
      cout<<"\n\n\n\n\n\n\n\tWould you like to run the conversion process again?\n\t\t\t\t(1 = Yes, 2 = No)\n\t\t\t\t\t";
      //The above output statement and the input line below require the user to
      //choose whether he/she would like to cycle through the base conversion
      //process again.  If the operator enters a "1," the first screen of the
      //application will reappear.  If the user presses any key other than "1,"
      //the project will terminate.
      cin>>cotinue;
      clrscr();
      }	while(cotinue == 1);
   return 0;
   }