/************************************** Mouse Demo Template **************************************************/
#include<dos.h>
#include<graphics.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<path_to_mouse_class/mouse.cls>
 
void main()
     {
     /* Mouse variables */
          int num_buttons;
          int buttons, x, y;
     /* A mouse object
          mouse myPointer;
     /* Your code to start graphics */
     /* Initialize the mouse */
          myPointer.Reset(&num_buttons);
     /* Now num_buttons holds the number of buttons on the mouse */
          myPointer.Show();
     /* The mouse pointer is now visible */
          myPointer.Status(&x, &y, &buttons);
     /* The variables x,y now store the location of the mouse and buttons now contains the status of the mouse buttons */
     /* Pause program execution so you can see the mouse */
          getch();
          myPointer.Hide();
     /* The pointer is no longer visible */
    /* Your code to close the graphics mode */
   }
 
/**************************************************** End Demo*****************************************************/
 
The above template says to put the video card into graphics mode. However, you do not have to. If you don't then the mouse pointer is not an arrow but a block. The above template also does not do anything with the mouse position or button status even though it does store those values in the x,y,buttons variables.
It is possible to put mouse.cls in your include directory so you do not have to include a path.
The above code will work for graphics, or without.  

Please direct all comments and suggestions to:
Jeremy Hise at 
JEREMYHISE@prodigy.net - Creator of mouse.cls
