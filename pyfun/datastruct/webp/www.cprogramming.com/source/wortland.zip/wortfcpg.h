//******************************************************************************
//*********The Main Header Page for Axels...--The game's second engine**********
//******************************************************************************


// D E F I N E S  ////////////////////////////////////////////////////////////

#define MODE13H             0x13
#define TEXT_MODE           0x03
#define PALETTE_MASK        0x3C6
#define PALETTE_REGISTER_RD 0x3C7
#define PALETTE_REGISTER_WR 0x3C8
#define PALETTE_DATA        0x3C9

typedef int tile[20][20];

// P R O T O T Y P E S ///////////////////////////////////////////////////////

void Video_Mode(int vmode);
void Plot_Pixel(int x, int y, unsigned char color);
void Set_PalReg(int index, unsigned char red, unsigned char green, unsigned char blue);
int  Get_PalReg(int index, int color);

void draw_line(int x1, int y1, int x2, int y2, int color);
void box_filled(int x1, int y1, int x2, int y2, int color);
void box_outlined(int x1, int y1, int x2, int y2, int color);
void box_in_box(int x1, int y1, int x2, int y2, int startc, int finishc);

void black_screen();
void fade_to_red(int slowness);

void twod_stars(int slowness, int NBR_STARS, int MinX, int MaxX, int MinY, int MaxY);
void InitStars(int NBR_STARS, int MinX, int MaxX, int MinY, int MaxY);
void DeleteStars(int NBR_STARS);void MoveStars(int NBR_STARS, int MinX, int MaxX, int MinY, int MaxY);
void DrawStars(int NBR_STARS);
void WR();
void load_stamp(tile stamp, apstring filename);
void display_stamp(const tile stamp, int topx, int topy);
void display_stamp_bon(const tile stamp, int topx, int topy);
void load_map(apstring filename);
void element_engine(int elements, ifstream &infile);
void display_map();

//Unique Functions to Game
void clear_keys();
void fix_path(apstring &path);
void load_files();
int title_screen();
void instructions();
void pause();
void display_score();
void display_lives();
void display_level();
void display_words();
void die();
void gameover();
void draw_pause_bars();
void popup_wrong(int index);
void update_enem();
void hit_enemy(int index);
void hit_word();
void level_done();
void game_complete();
void swing_chain(int x1, int y1);
void select_level();
void display_list();
void display_chal();

// G L O B A L S  //////////////////////////////////////////////////////////

unsigned char far *video_buffer = (char far *)0xA0000000L;
int DirX = -1, DirY = 0;

//Character/Enemy Tiles
tile charr;
tile charl;
tile charup;
tile chard;
tile chain1;
tile chain2;
tile chain3;
tile chain4;
tile chain5;
tile blank;

tile enem1r;
tile enem1l;
tile enem1u;
tile enem1d;
tile enem2r;
tile enem2l;
tile enem2u;
tile enem2d;
tile enem3r;
tile enem3l;
tile enem3u;
tile enem3d;
tile enem4r;
tile enem4l;
tile enem4u;
tile enem4d;
tile enem5r;
tile enem5l;
tile enem5u;
tile enem5d;
tile enem6r;
tile enem6l;
tile enem6u;
tile enem6d;

int ingame, inapp = 1;
apstring path = "d:/";
const int map_rows=7;
const int map_cols=6;
apstring map[(map_rows * map_cols)][3];
apmatrix<apstring> allwords;
int cemap[map_rows][map_cols];
int chardir, char_row, char_col;
int level_type, lives;
long int score;
const long int rel_hounds = 4000;
const long int erefresh = 1500;
int numenem;
int level, wordsleft;
int bonus;
int finishlevel;

int graphdriver = DETECT, graphmode;

// STRUCTURES ////////////////////////////////////////////////////////////

struct
	{	int x, y;
	char Plane;
	} Star[500];

struct
	{
	int row, col;
   int type;
   int dir;
   int on;
   int moves;
   }	enemies[10];


//**************************************************************************
//*******************FUNCTION PAGE BEGINS BELOW	****************************
//**************************************************************************

/////////////////////////////////////////////////////////////////////////////
// S E T _ P A L R E G                                                     //
// Set the color register for index to the specified value.                //
/////////////////////////////////////////////////////////////////////////////

void Set_PalReg(int index, unsigned char red, unsigned char green, unsigned char blue)
	{
  	// tell VGA card that a palette register will be updated
  	outportb(PALETTE_MASK, 0xff);
  	// tell VGA card which register to update we will be updating
  	outportb(PALETTE_REGISTER_WR, index);
  	// write the red, green, and blue values for the specified index
  	// to the VGA card (the same I/O port is used each time)
  	outportb(PALETTE_DATA, red);
  	outportb(PALETTE_DATA, green);
  	outportb(PALETTE_DATA, blue);
	}

/////////////////////////////////////////////////////////////////////////////
// G E T _ P A L R E G                                                     //
// Get the r, g, or b color value for specified index.                     //
/////////////////////////////////////////////////////////////////////////////

int Get_PalReg(int index, int color)
	{
  	int r, g, b;
  	outportb(PALETTE_MASK, 0xff);
  	outportb(PALETTE_REGISTER_RD, index);
  	r = inportb(PALETTE_DATA);
  	g = inportb(PALETTE_DATA);
  	b = inportb(PALETTE_DATA);
  	if     (color==1)
   	return r;
  	else if(color==2)
   	return g;
  	else if(color==3)
   	return b;
  	else
   	return 0;
	}

/////////////////////////////////////////////////////////////////////////////
// V I D E O _ M O D E                                                     //
// Sets the video mode to the value in vmode.                              //
/////////////////////////////////////////////////////////////////////////////

void Video_Mode(int vmode)
	{
  	asm mov ah, 0
  	asm mov al, BYTE PTR vmode
  	asm int 10h
	}

/////////////////////////////////////////////////////////////////////////////
// P L O T _ P I X E L                                                     //
// Plots a pixel to the video buffer.                                      //
/////////////////////////////////////////////////////////////////////////////

void Plot_Pixel(int x, int y, unsigned char color)
	{
  	video_buffer[((y<<8) + (y<<6)) + x] = color;
	}

//******************************************************************************************

void draw_line(int x1, int y1, int x2, int y2, int color)
	{
  	int i;
   if(x1 == x2)
   	{
      if(y1 < y2)
	      for(i=y1; i <= y2; ++i)
         	Plot_Pixel(x1, i, color);
   	else
      	for(i=y2; i <=y1; ++i)
         	Plot_Pixel(x1, i, color);
      }
   else
   	{
      double m, b;
	   m = ((y2-y1)*1.0)/(x2-x1);
  		b = y1 - m*x1;
	  	if(abs(x2-x1) > abs(y2-y1))
   		{  // draw along x-axis
    		if(x1 < x2)
      		for(i=x1; i<=x2; ++i)
         		Plot_Pixel(i, ((m*i)+b), color);
	    	else
   	   	for(i=x2; i<=x1; ++i)
      	  		Plot_Pixel(i, ((m*i)+b), color);
	  		}
  		else
   		{  // draw along y-axis
	    	if(y1 < y2)
   	   	for(i=y1; i<=y2; ++i)
      	      Plot_Pixel(((i-b)/m), i, color);
	    	else
   	   	for (i=y2; i<=y1; ++i)
      	  		Plot_Pixel(((i-b)/m), i, color);
    		}
      }
	}

//******************************************************************************************

void box_filled(int x1, int y1, int x2, int y2, int color)
	{
   if(y1 < y2)
	   for(int i = x1; i < x2; ++i)
   		for(int j = y1; j < y2; ++j)
      		Plot_Pixel(i, j, color);
   else
		for(int i = x1; i < x2; ++i)
   		for(int j = y2; j < y1; ++j)
      		Plot_Pixel(i, j, color);
   }

//******************************************************************************************

void box_outlined(int x1, int y1, int x2, int y2, int color)
	{
   draw_line(x1, y1, x2, y1, color);
   draw_line(x1, y2, x2, y2, color);
   draw_line(x1, y1, x1, y2, color);
   draw_line(x2, y1, x2, y2, color);
   }

//******************************************************************************************

void box_in_box(int x1, int y1, int x2, int y2, int startc, int finishc)
	{
   if(startc < finishc)
   	for(int currentc = startc; currentc <= finishc; ++currentc, --x1, --y1, ++x2, ++y2)
      	box_outlined(x1, y1, x2, y2, currentc);
   else
   	for(int currentc = startc; currentc >= finishc; --currentc, --x1, --y1, ++x2, ++y2)
      	box_outlined(x1, y1, x2, y2, currentc);
   }

//******************************************************************************************

void black_screen()
	{
   box_filled(0,0,320,200,0);
   }

//******************************************************************************************

void fade_to_red(int slowness)
	{
   int newred;
   for(int k=0; k <= 64; ++k)
   	{
	   for(int i=1; i <= 256; ++i)
   		{
         if(Get_PalReg(i, 1) < 60)
         	newred = Get_PalReg(i, 1) + 1;
         else
         	newred = Get_PalReg(i, 1);
	      Set_PalReg(i, newred, 0, 0);
   		}
      delay(slowness);
      }
   box_filled(0,0,320,200,4);
   delay(slowness * 60);
   Video_Mode(MODE13H);
   }

//******************************************************************************************

void twod_stars(int slowness, int NBR_STARS, int MinX, int MaxX, int MinY, int MaxY)
	{	InitStars(NBR_STARS, MinX, MaxX, MinY, MaxY);
	do
   	{
  		DeleteStars(NBR_STARS);  		MoveStars(NBR_STARS, MinX, MaxX, MinY, MaxY);      DrawStars(NBR_STARS);  		WR();      delay(slowness); 		} while( !kbhit() ); 	getch();	}
//******************************************************************************************

void InitStars(int NBR_STARS, int MinX, int MaxX, int MinY, int MaxY)	{
	for( int i = 0; i < NBR_STARS; i++ )
		{
		Star[ i ].x = ( rand() % (MaxX-MinX) ) + MinX;
		Star[ i ].y = ( rand() % (MaxY-MinY) ) + MinY;
		Star[ i ].Plane = rand() % 16;
	}
}

//******************************************************************************************

void DeleteStars(int NBR_STARS)	{
	for( int i = 0; i < NBR_STARS; i++ )
   	Plot_Pixel(Star[ i ].x, Star[ i ].y, 0);
	}

//******************************************************************************************

void MoveStars(int NBR_STARS, int MinX, int MaxX, int MinY, int MaxY)	{
	for( int i = 0; i < NBR_STARS; i++ )
		{
		Star[ i ].x += ( Star[ i ].Plane >> 1 ) * DirX + DirX;
		Star[ i ].y += ( Star[ i ].Plane >> 1 ) * DirY + DirY;
		if( Star[ i ].x > MaxX || Star[ i ].x < MinX ||
			Star[ i ].y > MaxY || Star[ i ].y < MinY )
  			{
			switch( DirX )
				{
				case -1:
					Star[ i ].x = MaxX;
					break;
				case 1:
					Star[ i ].x = MinX;
					break;
				case 0:
					Star[ i ].x = ( rand() % (MaxX-MinX) ) + MinX;
				}
         switch( DirY )
				{
				case -1:
					Star[ i ].y = MaxY;
					break;
				case 1:
					Star[ i ].y = MinY;
					break;
            case 0:
					Star[ i ].y = ( rand() % (MaxY-MinY) ) + MinY;
            }
			Star[ i ].Plane = rand() % 16;
			}
		}
	}

//******************************************************************************************

void DrawStars(int NBR_STARS)	{
	for( int i = 0; i < NBR_STARS; i++ )
      Plot_Pixel(Star[ i ].x, Star[ i ].y, Star[ i ].Plane + 16);
	}

//******************************************************************************************

void WR()	{
	asm mov dx, 3dah;
	WR_1:
		asm
      	{
         in al, dx
			test al, 8
			jnz WR_1
			}
	WR_2:
		asm
      	{
			in al, dx
			test al, 8
			jz WR_2
			}
	}

//************************************************************************************

void load_stamp(tile stamp, apstring filename)
	{
   int current_char;
   int row=0, col=0;
   ifstream infile;
   infile.open(filename.c_str());
   if(infile.fail())
   	{
		black_screen();
      gotoxy(1,1);
      cout<<"Fehler: Der Computer kann eine Datei\nnicht finden.\n\n\nDateiname: "<<filename<<"\n\n\n\n\nBeenden Sie das Programm jetzt!";
      for(int r=0; r < 20; ++r)
      	for(int c=0; c < 20; ++c)
         	stamp[r][c] = 0;
      getch();
      black_screen();
      }
   else
   	{
   	infile>>current_char;
   	while((! infile.eof()) && (current_char != 1000))
   		{
	      if((current_char >= 0) && (current_char < 17))
   	      {
      	   stamp[row][col] = current_char;
         	++col;
	         }
   	   else if(current_char == 999)
      		{
         	++row;
	         col = 0;
   	      }
      	infile>>current_char;
	      }
   	infile.close();
	   }
   }

//******************************************************************************************

void display_stamp(const tile stamp, int topx, int topy)
	{
   int row, column;
   for(row=0; row < 20; ++row)
   	for(column=0; column < 20; ++column)
      	{
      	if(stamp[row][column] != 0)
         	{
	         setcolor(stamp[row][column]);
   	      rectangle(((column * 2) + topx), ((row * 2) + topy), ((column * 2) + topx + 1), ((row * 2) + topy + 1));
      		}
			}
   }

//******************************************************************************************

void display_stamp_bon(const tile stamp, int topx, int topy)
	{
   int row, column;
   for(row=0; row < 20; ++row)
   	for(column=0; column < 20; ++column)
      	{
         setcolor(stamp[row][column]);
         rectangle(((column * 2) + topx), ((row * 2) + topy), ((column * 2) + topx + 1), ((row * 2) + topy + 1));
			}
   }

//******************************************************************************************

void load_map(apstring filename)
	{
   ifstream infile;
   infile.open(filename.c_str());
   if(infile.fail())
   	{
      cleardevice();
      gotoxy(1,1);
      cout<<"Fehler: Der Computer kann eine Datei\nnicht finden.\n\n\nDateiname: "<<filename<<"\n\n\n\n\nBeenden Sie das Programm jetzt!";
      getch();
      cleardevice();
      }
   allwords.resize(0, 0);
   if(filename == "gendbend.map")
   	element_engine(273, infile);
   else if(filename == "cats4.map")
   	element_engine(219, infile);
   else if(filename == "endings.map")
   	element_engine(143, infile);
   else if(filename == "cities.map")
   	element_engine(127, infile);
   else
   	element_engine(75, infile);
   infile.close();
   }

//******************************************************************************************

void element_engine(int elements, ifstream &infile)
	{
   time_t plague;
	time(&plague);
	srand((unsigned int)plague);
   apstring current_char;
   int element_num=0, map_slot=0;
   int option;   
   allwords.resize(elements, 3);
   while(map_slot < elements)
   	{
      infile>>current_char;
      allwords[map_slot][0] = current_char;
      infile>>current_char;
      allwords[map_slot][1] = current_char;
      infile>>current_char;
      for(int i=0; i < current_char.length(); ++i)
      	if(current_char[i] == '*')
         	current_char[i] = ' ';
      allwords[map_slot][2] = current_char;
      ++map_slot;
      }
   map_slot=0;
   while(map_slot < (map_rows * map_cols))
   	{
      if(element_num < ((elements * 3) - (map_rows * map_cols * 3)))
      	{
      	option = (rand() % 5);
         if(option == 3)
         	map[map_slot][0] = allwords[(element_num / 3)][0];
         if(option == 3)
         	map[map_slot][1] = allwords[(element_num / 3)][1];
         if(option == 3)
         	{
            current_char = allwords[(element_num / 3)][2];
            for(int i=0; i < current_char.length(); ++i)
            	if(current_char[i] == '*')
               	current_char[i] = ' ';
            map[map_slot][2] = current_char;
            ++map_slot;
            }
         element_num+=3;
         }
      else
       	{
         map[map_slot][0] = allwords[(element_num / 3)][0];
         map[map_slot][1] = allwords[(element_num / 3)][1];
         for(int i=0; i < allwords[(element_num / 3)][2].length(); ++i)
           	if(allwords[(element_num / 3)][2][i] == '*')
              	allwords[(element_num / 3)][2][i] = ' ';
         map[map_slot][2] = allwords[(element_num / 3)][2];
         ++map_slot;
         element_num+=3;
         }
	   }
   }

//******************************************************************************************

void display_map()
	{
   int row=0, col=0;
   int element;
   for(int r=0; r < map_rows; ++r)
   	for(int c=0; c < map_cols; ++c)
      	{
         element = cemap[r][c];
         switch (element)
         	{
            case 100:	display_stamp(charr, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 101:	display_stamp(charl, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 102:	display_stamp(charup, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 103:	display_stamp(chard, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 200:	display_stamp(enem1r, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 201:	display_stamp(enem1l, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 202:	display_stamp(enem1u, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 203:	display_stamp(enem1d, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 300:	display_stamp(enem2r, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 301:	display_stamp(enem2l, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 302:	display_stamp(enem2u, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 303:	display_stamp(enem2d, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 400:	display_stamp(enem3r, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 401:	display_stamp(enem3l, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 402:	display_stamp(enem3u, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 403:	display_stamp(enem3d, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 500:	display_stamp(enem4r, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 501:	display_stamp(enem4l, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 502:	display_stamp(enem4u, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 503:	display_stamp(enem4d, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 600:	display_stamp(enem5r, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 601:	display_stamp(enem5l, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 602:	display_stamp(enem5u, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 603:	display_stamp(enem5d, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 700:	display_stamp(enem6r, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 701:	display_stamp(enem6l, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 702:	display_stamp(enem6u, (c * 95 + 15), (r * 50 + 15));
            				break;
            case 703:	display_stamp(enem6d, (c * 95 + 15), (r * 50 + 15));
            }
         }
   setcolor(1);
   settextstyle(11, 0, 5);
   for(int index=0; index < (map_rows * map_cols); ++index)
   	{
      outtextxy((col * 88 + 25), (row * 50 + 30), map[index][0].c_str());
   	if(col == (map_cols - 1))
      	{
         ++row;
         col=-1;
         }
		++col;
      }
   }

//******************************************************************************************

void clear_keys()
	{
   while(kbhit())
   	getch();
   }

//******************************************************************************

void fix_path(apstring &path)
	{
   for(int letter=0; letter < (path.length()); ++letter)
   	if(path[letter] == '\'')
      	path[letter] = '/';
   if(path[(path.length() - 1)] != '/')
   	path = path + '/';
   }

//******************************************************************************

void load_files()
	{
   int x1, x2, y1, y2;
   black_screen();
   gotoxy(7, 2);
   cout<<"Axels Abenteuer in Wortland";
   gotoxy(2, 5);
   cout<<"Was ist der Weg fuer die\n Spiels Dateien?:\n ";
   cin>>path;
   fix_path(path);
   box_filled(0, 20, 319, 60, 0);
   box_filled(40, 34, 101, 43, 4);
   gotoxy(2, 4);
   cout<<"Loading Character: ";
   load_stamp(charr, (path + "charr.til"));
   box_filled(41, 35, 46, 42, 43);
   load_stamp(charl, (path + "charl.til"));
   box_filled(47, 35, 52, 42, 43);
   load_stamp(chard, (path + "chard.til"));
   box_filled(53, 35, 58, 42, 43);
   load_stamp(charup, (path + "charup.til"));
   box_filled(59, 35, 64, 42, 43);
   load_stamp(chain1, (path + "chain1.til"));
   box_filled(65, 35, 70, 42, 43);
   load_stamp(chain2, (path + "chain2.til"));
   box_filled(71, 35, 76, 42, 43);
   load_stamp(chain3, (path + "chain3.til"));
   box_filled(77, 35, 82, 42, 43);
   load_stamp(chain4, (path + "chain4.til"));
   box_filled(83, 35, 88, 42, 43);
   load_stamp(chain5, (path + "chain5.til"));
   box_filled(89, 35, 94, 42, 43);
   load_stamp(blank, (path + "blank.til"));
   box_filled(95, 35, 100, 42, 43);
   cout<<"Complete";
   box_filled(40, 67, 185, 76, 4);
   gotoxy(2, 8);
   cout<<"Loading Enemies: ";
   load_stamp(enem1r, (path + "enem1r.til"));
   box_filled(41, 68, 46, 75, 43);
   load_stamp(enem1l, (path + "enem1l.til"));
   box_filled(47, 68, 52, 75, 43);
   load_stamp(enem1u, (path + "enem1u.til"));
   box_filled(53, 68, 58, 75, 43);
   load_stamp(enem1d, (path + "enem1d.til"));
   box_filled(59, 68, 64, 75, 43);
   load_stamp(enem2r, (path + "enem2r.til"));
   box_filled(65, 68, 70, 75, 43);
   load_stamp(enem2l, (path + "enem2l.til"));
   box_filled(71, 68, 76, 75, 43);
   load_stamp(enem2u, (path + "enem2u.til"));
   box_filled(77, 68, 82, 75, 43);
   load_stamp(enem2d, (path + "enem2d.til"));
   box_filled(83, 68, 88, 75, 43);
   load_stamp(enem3r, (path + "enem3r.til"));
   box_filled(89, 68, 94, 75, 43);
   load_stamp(enem3l, (path + "enem3l.til"));
   box_filled(95, 68, 100, 75, 43);
   load_stamp(enem3u, (path + "enem3u.til"));
   box_filled(101, 68, 106, 75, 43);
   load_stamp(enem3d, (path + "enem3d.til"));
   box_filled(107, 68, 112, 75, 43);
   load_stamp(enem4r, (path + "enem4r.til"));
   box_filled(113, 68, 118, 75, 43);
   load_stamp(enem4l, (path + "enem4l.til"));
   box_filled(119, 68, 124, 75, 43);
   load_stamp(enem4u, (path + "enem4u.til"));
   box_filled(125, 68, 130, 75, 43);
   load_stamp(enem4d, (path + "enem4d.til"));
   box_filled(131, 68, 136, 75, 43);
   load_stamp(enem5r, (path + "enem5r.til"));
   box_filled(137, 68, 142, 75, 43);
   load_stamp(enem5l, (path + "enem5l.til"));
   box_filled(143, 68, 148, 75, 43);
   load_stamp(enem5u, (path + "enem5u.til"));
   box_filled(149, 68, 154, 75, 43);
   load_stamp(enem5d, (path + "enem5d.til"));
   box_filled(155, 68, 160, 75, 43);
   load_stamp(enem6r, (path + "enem6r.til"));
   box_filled(161, 68, 166, 75, 43);
   load_stamp(enem6l, (path + "enem6l.til"));
   box_filled(167, 68, 172, 75, 43);
   load_stamp(enem6u, (path + "enem6u.til"));
   box_filled(173, 68, 178, 75, 43);
   load_stamp(enem6d, (path + "enem6d.til"));
   box_filled(179, 68, 184, 75, 43);
   cout<<"Complete";
   getch();
   fade_to_red(40);
   gotoxy(6, 3);
   cout<<"Ryan Lloyd ueberreichnet...";
   twod_stars(25, 320, 0, 319, 30, 199);
	gotoxy(14, 22);
   cout<<"Copyright 2001";
   for(x1=160, x2=160, y1=100, y2=100; x1 > 80; --x1, ++x2)
   	{
      box_outlined(x1, y1, x2, y2, 32);
      box_outlined((x1 + 1), (y1 + 1), (x2 - 1), (y2 - 1), 0);
      delay(30);
      if(y1 > 60)
      	{
         --y1;
         ++y2;
         }
      }
   gotoxy(14, 12);
   cout<<"Axels Abenteuer";
   gotoxy(16, 13);
   cout<<"in Wortland";
   box_in_box(x1, (y1 - 1), x2, (y2 + 1), 40, 49);
   getch();
	fade_to_red(25);
   }

//******************************************************************************************

int title_screen()
	{
   initgraph(&graphdriver, &graphmode, (path - '/').c_str());
   int madechoice, current_choice;
   int exitmenu = 0;
   int keycode;
   int slot;
   while(exitmenu == 0)
   	{
      madechoice = 0;
	   current_choice = 0;
      cleardevice();
      for(slot = 0; slot < 12; ++slot)
   		display_stamp(charr, 0, (slot * 40));
	   for(slot = 1; slot < 16; ++slot)
   		display_stamp(charup, (slot * 40), 440);
	   for(slot = 10; slot >= 0; --slot)
   		display_stamp(charl, 600, (slot * 40));
	   for(slot = 14; slot > 0; --slot)
   		display_stamp(chard, (slot * 40), 0);
		setcolor(10);
		settextstyle(10,0,3);
		outtextxy(235, 45, "Hauptmenue");
   	setcolor(5);
	   rectangle(100, 100, 560, 385);
   	rectangle(103, 103, 557, 382);
	   rectangle(106, 106, 554, 379);
		setcolor(9);
		settextstyle(6,0,5);
		outtextxy(155, 110, "Spielen das ganze Spiel");
      outtextxy(155, 150, "Spielen ein Stadium");
		outtextxy(155, 190, "Gebrauchsanweisung");
		outtextxy(155, 230, "Gehen zum Ausgang");
	   setcolor(14);
   	outtextxy(125, 110, ">");
	   while(madechoice == 0)
   		{
     	 	if(kbhit())
      		{
	         keycode = getch();
   	      if(keycode == 56)
      	   	{
         	   setcolor(0);
            	outtextxy(125, (110 + (current_choice * 40)), ">");
	            if(current_choice == 0)
   	            current_choice = 3;
      	      else
         	   	--current_choice;
            	setcolor(14);
	            outtextxy(125, (110 + (current_choice * 40)), ">");
   	         }
      	   else if(keycode == 50)
         		{
            	setcolor(0);
	            outtextxy(125, (110 + (current_choice * 40)), ">");
   	         if(current_choice == 3)
      	      	current_choice = 0;
         	   else
            		++current_choice;
	            setcolor(14);
   	         outtextxy(125, (110 + (current_choice * 40)), ">");
      	      }
         	else if((keycode == 13) || (keycode == 32))
            	madechoice = 1;
	         }
     	   }
	   if(current_choice < 2)
      	{
         ingame = 1;
   		exitmenu = 1;
         }
	   else if(current_choice == 2)
			instructions();
	   else if(current_choice == 3)
      	{
   	   inapp = 0;
         ingame = 0;
         exitmenu = 1;
         }
		}
   return current_choice;
   }

//******************************************************************************************

void instructions()
	{
   cleardevice();
   setcolor(12);
   settextstyle(10, 0, 3);
   outtextxy(20, 20, "Gebrauchsanweisung: Geschichte");
   cout<<"\n\n\n\n\n    Axel Wanxian und seine vier Freunde haben entschieden, dass sie wollen nach\n";
   cout<<"Berlin fuer eine Reise gehen.  Berlin ist die Hauptstadt von Deutschland, und\n";
   cout<<"die fuenf Freunde waren aufgeregt, um Berlin zu sehen.  Die Gruppe begann die\n";
   cout<<"Reise von Freiburg, der Geburtsort der Freunde.  Als die fuenf gruenen Bloecke\n";
	cout<<"nach Stuttgart gekommen sind, sechs Banditen--ein blaues Monster, ein roter\n";
   cout<<"Feind, ein graues Tier, ein purpures Monster, ein gelber Feind, und ein weisser\n";
   cout<<"Bandit mit einem Bettlaken auf seinem Kopf--sind auf Axel und seine Freunde\n";
	cout<<"gesprungen.  Das purpure Tier hat den Kopf eines Freundes von Axel gegessen,\n";
   cout<<"und das Lebewesen hat die Beine und die Arme eines anderen gruenen Blockes\n";
   cout<<"gefressen.  Der purpure, blutige Feind grub seine Zaehne in dem Darm eines\n";
   cout<<"dritten Freund von Axel.  Danach hat das Monster die Muskeln von Axels letzten\n";
   cout<<"Freund mit einer Gabel und einem Messer gefressen.  Axel war jetzt in einer\n";
   cout<<"Panik.  Er erreichte fuer seine Kette, und Axel schlug das Monster im Kopf mit\n";
   cout<<"der Waffe.  Die Kette nahm ein paar Zaehne des Monsters heraus.  Der Feind gab\n";
   cout<<"Befehle zu den anderen fuenf Tiere.  Er wollte die Tiere Axel zu ihrem\n";
   cout<<"zweiundvierzig-Morgen Gut in der Naehe von Stuttgart bringen, weil er Angst\n";
   cout<<"vor Axel hatte.  Bei dem Versteck gaben die sechs boesen Bloecke eine\n";
   cout<<"Herausforderung zu Axel.  Ob Axel zwanzig Runden von Schrecken mit den Tiere\n";
	cout<<"ueberleben kann, die Feinde werden Axel auf seiner Reise nach Berlin entlassen.\n";
   cout<<"Axel muss Woerter finden in Wortland (Wortland ist das Gut der Tiere), und die\n";
   cout<<"Woerter muessen die Bloeckes Bedingungen erfuellen.  Inzwischen werden die\n";
   cout<<"Tiere Axel jagen.  Jedoch hat Axel anderen Plaene...\n\n\n";
   cout<<"\t\t\tDruecken Sie eine Taste zu weitergehen!";
   getch();
   cleardevice();

   setcolor(12);
   outtextxy(10, 20, "Gebrauchsanweisung: Feinde");
   gotoxy(1, 10);
   cout<<"Dieses Monster ist nicht sehr intelligent.  Es kann nur in einer Reihe (sechs\nSchlitze) oder in einer Saeule (sieben Schlitze) bewegen.  Es will Axel\nfressen, aber das blaue Monster ist nicht sehr schnell.  Es ist in Stadium\neins durch Stadium neun.";
   gotoxy(1, 17);
   cout<<"Dieser Feind weiss nicht, wo Axel ist.  Das Monster geht von Schlitz bis\nSchlitz mit keinem Muster; es bewegt sich zufaellig.  Es hat\nungefaehr fuenf Zuege, und das Monster sieht manchmal dumm aus.  Der rote\nFeind ist betrunken moeglicherweise, aber er ist eine grosse Gefahr, wenn\ner in der Naehe von Axel ist.\n\n\n\n";
	cout<<"Der graue Feind hat ein bisschen kuenstliche Intelligenz.  Er weiss, wo Axel\nauf der Landkarte ist, und das Monster wird fuer deinen Charakter suchen.\nDer Feind bewegt von Saeule bis Saeule, bis das Monster in Axels Saeule\nist.  Dann er wird nach unten oder nach oben bewegen, bis\ner Axel fressen.";
   setcolor(14);
   settextstyle(9, 0, 2);
   outtextxy(10, 100, "das blaues Monster");
   outtextxy(10, 210, "das rotes Monster");
   outtextxy(10, 343, "das graues Monster");
   display_stamp(enem1r, 400, 100);
   display_stamp(enem2r, 400, 210);
   display_stamp(enem3r, 400, 343);
   gotoxy(20, 6);
   cout<<"Druecken Sie eine Taste zu weitergehen!";
   getch();
   cleardevice();

   settextstyle(10, 0, 3);
   setcolor(12);
   outtextxy(10, 10, "Gebrauchsanweisung: Feinde");
   gotoxy(1, 9);
   cout<<"Dieses Monster hat das graue Monsters Intelligenz.  Das Monster wird nach\nAxels Reihe gehen, und dann es bewegt von Saeule bis Saeule, bis das purpure\nMonster isst Axel.  Es weiss Axels Position, und es wird fuer den Charakter\njagen.  Das blutige, purpure Monster hat alle Axels Freunde gefressen,\nund er will Axel fuer Abendessen.  Der Feind ist in Stadium zehn durch\nStadium zwanzig.";
   gotoxy(1, 18);
   cout<<"Der gelbe Feind ist sehr boese und sehr schnell.  Er hat einen grauen Bart\naber keinen Schnurrbart.  Das Monster wird fuer Axel suchen; es ist nicht\ndumm.  Der Feind kann diagonal, vertikal, und horizontal bewegen.  Der\nSpieler kann auch das gelbe Monster in Stadium zehn durch Stadium zwanzig\nsehen.\n\n\n\n";
	cout<<"Dieser Feind ist einem Geist aehnlich.  Weiss ist das Monster, und es hat\ngelben Fuesse.  Es ist ein Feigling vielleicht.  Der Feind hat keine\nIntelligenz, und er geht von Schlitz bis Schlitz mit keinem Muster.  Er kann\nhinter Axel erscheinen, oder das weisse Monster wird vor dem Charakter gehen.\nDieses Tier ist in Stadium achtzehn bis Stadium zwanzig.";
   setcolor(14);
   settextstyle(9, 0, 2);
   outtextxy(10, 85, "das purpure Monster");
   outtextxy(10, 224, "das gelbe Monster");
   outtextxy(10, 348, "das weisse Monster");
   display_stamp(enem4r, 400, 85);
   display_stamp(enem5r, 400, 224);
   display_stamp(enem6r, 400, 348);
   gotoxy(20, 5);
   cout<<"Druecken Sie eine Taste zu weitergehen!";
   getch();
   cleardevice();

   setcolor(12);
   settextstyle(10, 0, 3);
   outtextxy(60, 20, "Gebrauchsanweisung: Punkte");
   setcolor(1);
   settextstyle(2, 0, 8);
   outtextxy(60, 80, "Stadiumtyp:");
 	settextstyle(2, 0, 6);
   setcolor(9);
   outtextxy(60, 120, "maennlichen Hauptwoerter");
   outtextxy(60, 140, "femininen Hauptwoerter");
   outtextxy(60, 160, "saechlichen Hauptwoerter");
   outtextxy(60, 180, "Essen");
   outtextxy(60, 200, "Klamotten");
   outtextxy(60, 220, "um das Haus herum");
   outtextxy(60, 240, "Verben");
   outtextxy(60, 260, "Hauptwoerter");
   outtextxy(60, 280, "Adjektive");
   outtextxy(60, 300, "Staedte in Deutschland");
   outtextxy(60, 320, "Formen von may");
   outtextxy(60, 340, "Formen von should");
   outtextxy(60, 360, "Formen von can");
   outtextxy(60, 380, "Formen von to want");
   outtextxy(60, 400, "Formen von must");
   outtextxy(60, 420, "Formen von to like");
   setcolor(13);
   outtextxy(320, 120, "einhundert Punkte");
   outtextxy(320, 140, "einhundert Punkte");
   outtextxy(320, 160, "einhundert Punkte");
   outtextxy(320, 180, "fuenfundachtzig Punkte");
   outtextxy(320, 200, "fuenfundachtzig Punkte");
   outtextxy(320, 220, "fuenfundachtzig Punkte");
   outtextxy(320, 240, "siebzig Punkte");
   outtextxy(320, 260, "siebzig Punkte");
   outtextxy(320, 280, "siebzig Punkte");
   outtextxy(320, 300, "zweihundert Punkte");
   outtextxy(320, 320, "achtzig Punkte");
   outtextxy(320, 340, "achtzig Punkte");
   outtextxy(320, 360, "achtzig Punkte");
   outtextxy(320, 380, "achtzig Punkte");
   outtextxy(320, 400, "achtzig Punkte");
   outtextxy(320, 420, "achtzig Punkte");
   gotoxy(38, 6);
   cout<<"Druecken Sie eine Taste zu weitergehen!";
   getch();
   cleardevice();

   setcolor(12);
   settextstyle(10, 0, 3);
   outtextxy(0, 20, "Gebrauchsanweisung: eine Praemie");
	cout<<"\n\n\n\n\n\tWenn Axel mit einem Stadium fertig ist, er kann eine Praemie\nbekommen.  Ob er nicht im Stadium gestorben ist (Axel ist tot, wenn er ein\nschlechtes Wort oder ein Monster trifft), Axel bekommt viele Punkte.  Die\nPraemie ist das Produkt von Axels Stadium und zweihundert Punkte.";
   cout<<"\n\n\n\tAxel kann auch ein zusaetzliches Leben erhalten, wenn er zehntausend\nPunkte, zwanzigtausend Punkte, dreissigtausend Punkte, etc. bekommt."; 
   gotoxy(20, 25);
   cout<<"Druecken Sie eine Taste zu weitergehen!";
   getch();
   cleardevice();

   setcolor(12);
   settextstyle(10, 0, 3);
   outtextxy(60, 20, "Gebrauchsanweisung: Tasten");
   setcolor(2);
   settextstyle(6, 0, 3);
   outtextxy(10, 100, "<Space Bar> oder <Enter> =");
   outtextxy(50, 130, "Axel kann ein Wort fressen.");
   outtextxy(10, 180, "<Escape> =");
   outtextxy(50, 210, "Axel haelt das Spiel.");
   setcolor(14);
   settextstyle(8, 0, 3);
   outtextxy(10, 262, "Richtsteuerung:");
   setcolor(4);
   rectangle(320, 100, 560, 280);
   rectangle(400, 100, 480, 280);
   rectangle(320, 160, 560, 220);
   setcolor(1);
	outtextxy(405, 110, "Acht");
	outtextxy(330, 170, "Vier");
	outtextxy(485, 170, "Sechs");
	outtextxy(405, 230, "Zwei");
   setcolor(2);
   settextstyle(6, 0, 3);
   outtextxy(60, 300, "Acht = Axel wird oben gehen.");
   outtextxy(60, 340, "Zwei = Der Charakter wird nach unten bewegen.");
   outtextxy(60, 380, "Vier = Axel kann links gehen.");
   outtextxy(60, 420, "Sechs = Der Charakter darf rechts bewegen.");
   gotoxy(38, 6);
   cout<<"Druecken Sie eine Taste zu weitergehen!";
   getch();
	}

//******************************************************************************************

void pause()
	{
   int currentopt = 0, madechoice = 0;
   int keycode;
   setcolor(4);
   rectangle(12, 418, 240, 470);
   setcolor(3);
   rectangle(6, 414, 615, 478);
   while(madechoice == 0)
   	{
      if(kbhit())
      	{
         keycode = getch();
         if((keycode == 32) || (keycode == 13))
         	madechoice = 1;
         else if(keycode == 27)
         	{
            madechoice = 1;
            currentopt = 3;
            }
         else if((keycode == 52) && (currentopt > 0))
         	--currentopt;
         else if((keycode == 54) && (currentopt < 1))
         	++currentopt;
         if((keycode == 54) || (keycode == 52))
         	{
				draw_pause_bars();
            setcolor(4);
            switch (currentopt)
            	{
               case 0: rectangle(12, 418, 240, 470);
               	     break;
               case 1: rectangle(240, 418, 600, 470);
               }
            }
         }
      }
   if(currentopt == 0)
   	ingame = 0;
   else
		draw_pause_bars();
   setcolor(0);
   rectangle(6, 414, 615, 478);
   }

//******************************************************************************************

void display_score()
	{
   gotoxy(18, 25);
   cout<<score;
   }

//******************************************************************************************

void display_lives()
	{
   setcolor(0);
   int x1, x2, y1, y2;
   for(x1=600, x2=639, y1=50, y2=70; x1 < 620; ++x1, --x2, ++y1, --y2)
   	rectangle(x1, y1, x2, y2);
   gotoxy(76, 4);
   cout<<lives;
   }

//******************************************************************************************

void display_level()
	{
   gotoxy(76, 16);
   cout<<level;
   }

//******************************************************************************************

void display_words()
	{
   setcolor(0);
   int x1, x2, y1, y2;
   for(x1=560, x2=639, y1=150, y2=180; y1 < 167; ++x1, --x2, ++y1, --y2)
   	rectangle(x1, y1, x2, y2);
   gotoxy(76, 11);
   cout<<wordsleft;
   }

//******************************************************************************************

void die()
	{
   --lives;
   if(lives < 0)
   	gameover();
   else
	   display_lives();
   }

//******************************************************************************************

void gameover()
	{
   clear_keys();
   ingame = 0;
   cleardevice();
   setcolor(11);
   settextstyle(10, 0, 7);
   outtextxy(210,10, "SPIEL");
   outtextxy(85,120, "VERLOREN");
   setcolor(1);
   settextstyle(8, 0, 6);
   outtextxy(50,265, "oberste Spielstand");
   gotoxy(39,23);
   cout<<score;
   getch();
   }

//******************************************************************************************

void draw_pause_bars()
	{
   setcolor(15);
   rectangle(12, 418, 240, 470);
   rectangle(240, 418, 600, 470);
   }

//******************************************************************************************

void popup_wrong(int index)
	{
   int x1, x2, y1, y2;
   clear_keys();
   setcolor(0);
   for(x1=320, x2=320, y1=240, y2=240; x1 > 215; --x1, ++x2, --y1, ++y2)
   	{
   	rectangle(x1, y1, x2, y2);
      delay(1);
      }
   setcolor(4);
   rectangle(x1, y1, x2, y2);
   settextstyle(6, 0, 4);
   outtextxy(240, 150, "Nicht Richtig!");
   gotoxy(29, 15);
   cout<<"\""<<map[index][0]<<"\" is ";
   if((level_type >= 0) && (level_type <= 2))
      {
		if(map[index][1] == "m")
      	cout<<"masculine";
      else if(map[index][1] == "f")
      	cout<<"feminine";
      else
      	cout<<"neuter";
      gotoxy(29, 16);
      cout<<"and means";
      gotoxy(29, 17);
      cout<<"\""<<map[index][2]<<"\"";
		}
   else if((level_type >= 3) && (level_type <= 5))
      {
      cout<<"a ";
      if(map[index][1] == "c")
      	cout<<"clothing";
      else if(map[index][1] == "d")
      	cout<<"food";
      else
      	cout<<"house";
      cout<<" item";
      gotoxy(29, 16);
      cout<<"and means";
      gotoxy(29, 17);
      cout<<"\""<<map[index][2]<<"\"";
      }
 	else if((level_type >= 6) && (level_type <= 8))
		{
      if(map[index][1] == "n")
      	cout<<"a noun";
      else if(map[index][1] == "v")
      	cout<<"a verb";
      else
      	cout<<"an adjective";
      gotoxy(29, 16);
      cout<<"and means";
      gotoxy(29, 17);
      cout<<"\""<<map[index][2]<<"\"";
      }
   else if(level_type == 9)
      {
   	cout<<"a city in";
      gotoxy(29, 16);
      cout<<map[index][2];
      }
   else
   	{
      cout<<"a form of ";
      gotoxy(29, 16);
      if(map[index][1] == "s")		//sollen
         cout<<"\"sollen\"";
      else if(map[index][1] == "d")		//duerfen
         cout<<"\"duerfen\"";
      else if(map[index][1] == "k")		//koennen
         cout<<"\"koennen\"";
      else if(map[index][1] == "w")		//wollen
         cout<<"\"wollen\"";
      else if(map[index][1] == "m")		//moegen
         cout<<"\"moegen\"";
      else                          	//muessen
         cout<<"\"muessen\"";
      cout<<" and means";
      gotoxy(29, 17);
      cout<<"\""<<map[index][2]<<"\"";
      }
   getch();
   die();
   if(ingame == 1)
   	{
	   setcolor(0);
   	for(x1=320, x2=320, y1=240, y2=240; x1 > 214; --x1, ++x2, --y1, ++y2)
   		rectangle(x1, y1, x2, y2);
	   setcolor(10);
   	for(int r=0; r < (map_rows + 1); ++r)
   		line(10, (10 + r * 50), 550, (10 + r * 50));
	   for(int c=0; c < (map_cols + 1); ++c)
   		line((10 + c * 90), 10, (10 + c * 90), 360);
      }
   }

//******************************************************************************************

void update_enem()
	{
   time_t plague;
	time(&plague);
	srand((unsigned int)plague);
   int index;
   int newdir;
   for(index=0; index < 10; ++index)
      if(enemies[index].on == 1)
      	{
         cemap[enemies[index].row][enemies[index].col] = 0;
	      display_stamp(blank, (enemies[index].col * 95 + 15), (enemies[index].row * 50 + 15));
   	   if(((enemies[index].col == 0) && (enemies[index].dir == 2)) || ((enemies[index].col == 5) && (enemies[index].dir == 1)) || ((enemies[index].row == 0) && (enemies[index].dir == 3)) || ((enemies[index].row == 6) && (enemies[index].dir == 4)) || ((enemies[index].moves < 0) && (enemies[index].type > 2)))
            {
      		--numenem;
            enemies[index].on = 0;
            }
	      else
   	   	{
            switch(enemies[index].type)
            	{
	      	   case 1:	switch(enemies[index].dir)
   	      					{
      	      				case 1:	++enemies[index].col;
		         	   					break;
	         	   			case 2:  --enemies[index].col;
   			         					break;
	      	      			case 3:	--enemies[index].row;
   	      			   				break;
      	      				case 4:	++enemies[index].row;
	      	      			}
               			break;
               case 2:	if((enemies[index].col == 0) || (enemies[index].col == 5) || (enemies[index].row == 0) || (enemies[index].row == 6))
                        	switch(enemies[index].dir)
   	      						{
      	      					case 1:	++enemies[index].col;
                              			break;
	         	   				case 2:  --enemies[index].col;
                              			break;
	      	      				case 3:	--enemies[index].row;
   	      			   					break;
      	      					case 4:	++enemies[index].row;
	      	      				}
								else
                        	{
	               			newdir = (rand() % 4) + 1;
   	            			enemies[index].dir = newdir;
      	                  switch(newdir)
   	   	   					{
      	   	   				case 1:	++enemies[index].col;
		         		   					break;
	         	   				case 2:  --enemies[index].col;
   			         						break;
		      	      			case 3:	--enemies[index].row;
   		      			   				break;
      		      				case 4:	++enemies[index].row;
	      		      			}
                           }
                 			break;
               case 3:	if(enemies[index].col < char_col)
               				{
               				++enemies[index].col;
                           enemies[index].dir = 1;
                           }
               			else if(enemies[index].col > char_col)
                        	{
                           --enemies[index].col;
                           enemies[index].dir = 2;
                           }
                        else if(enemies[index].row < char_row)
                        	{
                           ++enemies[index].row;
                           enemies[index].dir = 4;
                           }
                        else if(enemies[index].row > char_row)
                        	{
                           --enemies[index].row;
                           enemies[index].dir = 3;
                           }
                        --enemies[index].moves;
               			break;
               case 4:	if(enemies[index].row < char_row)
                        	{
                           ++enemies[index].row;
                           enemies[index].dir = 4;
                           }
                        else if(enemies[index].row > char_row)
                        	{
                           --enemies[index].row;
                           enemies[index].dir = 3;
                           }
                        else if(enemies[index].col < char_col)
               				{
               				++enemies[index].col;
                           enemies[index].dir = 1;
                           }
               			else if(enemies[index].col > char_col)
                        	{
                           --enemies[index].col;
                           enemies[index].dir = 2;
                           }
                        --enemies[index].moves;
               			break;
               case 5:	if(enemies[index].row < char_row)
                        	{
                           ++enemies[index].row;
                           enemies[index].dir = 4;
                           }
                        else if(enemies[index].row > char_row)
                        	{
                           --enemies[index].row;
                           enemies[index].dir = 3;
                           }
                        if(enemies[index].col < char_col)
               				{
               				++enemies[index].col;
                           enemies[index].dir = 1;
                           }
               			else if(enemies[index].col > char_col)
                        	{
                           --enemies[index].col;
                           enemies[index].dir = 2;
                           }
                        break;
               case 6:  enemies[index].col = (rand() % (map_cols - 1)) + 1;
               			enemies[index].row = (rand() % (map_rows - 1)) + 1;
               }
            for(int i=0; i < 10; ++i)
               if((enemies[i].col == enemies[index].col) && (enemies[i].row == enemies[index].row) && (i != index))
                  {
			         cemap[enemies[i].row][enemies[i].col] = 0;
	      			display_stamp(blank, (enemies[i].col * 95 + 15), (enemies[i].row * 50 + 15));
                  switch(enemies[index].dir)
	         			{
   		         	case 1:	enemies[index].dir = 2;
                     			--enemies[index].col;
                     			enemies[i].dir = 1;
      		      				break;
		      	      case 2:  enemies[index].dir = 1;
                     			++enemies[index].col;
                     			enemies[i].dir = 2;
   		      	     			break;
      	      		case 3:	enemies[index].dir = 4;
                     			++enemies[index].row;
                     			enemies[i].dir = 3;
         		   				break;
	      	      	case 4:	enemies[index].dir = 3;
                     			--enemies[index].row;
                     			enemies[i].dir = 4;
			            }
                  }
				cemap[enemies[index].row][enemies[index].col] = ((enemies[index].type + 1) * 100) + (enemies[index].dir-1);
   	      }
         if((enemies[index].row == char_row) && (enemies[index].col == char_col))
				hit_enemy(index);
	      }
   display_map();
   }

//******************************************************************************************

void hit_enemy(int index)
	{
   int x1, x2, y1, y2;
   clear_keys();
   bonus = 0;
   if(index == -1)
   	{
      for(int i=0; i < 10; ++i)
         if((enemies[i].row == char_row) && (enemies[i].col == char_col))
         	index = i;
      }
   setcolor(3);
	for(x1=320, x2=320, y1=240, y2=240; x1 > 215; --x1, ++x2, --y1, ++y2)
   	{
      rectangle(x1, y1, x2, y2);
      delay(1);
      }
   setcolor(2);
   rectangle(x1, y1, x2, y2);
   setcolor(15);
   settextstyle(6, 0, 4);
   outtextxy(240, 170, "Das");
   switch(enemies[index].type)
   	{
      case 1:	outtextxy(305, 170, "blaue");
      			display_stamp_bon(enem1d, 300, 295);
      			break;
      case 2:  outtextxy(305, 170, "rote");
      			display_stamp_bon(enem2d, 300, 295);
      			break;
      case 3:  outtextxy(305, 170, "graue");
      			display_stamp_bon(enem3d, 300, 295);
      			break;
      case 4:  outtextxy(305, 170, "purpure");
      			display_stamp_bon(enem4d, 300, 295);
      			break;
      case 5:  outtextxy(305, 170, "gelbe");
      			display_stamp_bon(enem5d, 300, 295);
      			break;
      case 6:  outtextxy(305, 170, "weisse");
      			display_stamp_bon(enem6d, 300, 295);
      }
   outtextxy(240, 210, "Monster frisst");
   outtextxy(240, 250, "dich!");
   clear_keys();
   getch();
   die();
   if(ingame == 1)
   	{
      setcolor(0);
      for(x1=320, x2=320, y1=240, y2=240; x1 > 214; --x1, ++x2, --y1, ++y2)
      	rectangle(x1, y1, x2, y2);
      setcolor(10);
      for(int r=0; r < (map_rows + 1); ++r)
      	line(10, (10 + r * 50), 550, (10 + r * 50));
      for(int c=0; c < (map_cols + 1); ++c)
      	line((10 + c * 90), 10, (10 + c * 90), 360);
      }
   enemies[index].on = 0;
   display_stamp(blank, (enemies[index].col * 95 + 15), (enemies[index].row * 50 + 15));
   switch(chardir)
   	{
      case 1:	cemap[enemies[index].row][enemies[index].col] = 100;
      			break;
      case 2:	cemap[enemies[index].row][enemies[index].col] = 101;
			      break;
      case 3:	cemap[enemies[index].row][enemies[index].col] = 102;
   			   break;
      case 4:	cemap[enemies[index].row][enemies[index].col] = 103;
      }
   }

//******************************************************************************************

void hit_word()
	{
   --wordsleft;
   if(wordsleft == 0)
   	{
      level_done();
      finishlevel = 1;
      }
   else
   	{
      display_score();
      display_words();
      }
   }

//******************************************************************************************

void level_done()
	{
   int slot;
   long int origscore = score;
   cleardevice();
	clear_keys();
   if(kbhit())
   	getch();
   for(slot = 0; slot < 12; ++slot)
   	display_stamp(enem5r, 0, (slot * 40));
   for(slot = 1; slot < 16; ++slot)
   	display_stamp(enem5u, (slot * 40), 440);
   for(slot = 10; slot >= 0; --slot)
   	display_stamp(enem5l, 600, (slot * 40));
   for(slot = 14; slot > 0; --slot)
   	display_stamp(enem5d, (slot * 40), 0);
   setcolor(15);
   settextstyle(10, 0, 4);
   outtextxy(110, 80, "Stadium ist fertig!");
   display_stamp(charr, 300, 155);
   settextstyle(8, 0, 5);
   outtextxy(60, 240, "Praemie:");
   if(bonus == 1)
   	{
      gotoxy(35, 18);
      score+=(200 * level);
	   cout<<(200 * level);
      if((origscore < 10000) && (score >= 10000))
      	++lives;
      }
   else
   	outtextxy(60, 290, "Keine Praemie");
   getch();
   }

//******************************************************************************************

void game_complete()
	{
   cleardevice();
   int x1, y1, x2, slot;
   for(x1=600, y1=5; y1 < 90; x1-=4, y1+=4)
   	display_stamp_bon(chain1, x1, y1);
   for(x2=0; x1 > 205; x1-=4)
   	{
   	display_stamp_bon(enem1r, x2, y1);
   	display_stamp_bon(chain1, x1, y1);
      if(x2 < 150)
      	x2+=2;
      }
	swing_chain(x1, y1);
   for(int rev=0; rev < 7; ++rev)
   	{
	   display_stamp_bon(enem1d, x2, y1);
		delay(200);
	   display_stamp_bon(enem1r, x2, y1);
		delay(200);
	   display_stamp_bon(enem1u, x2, y1);
		delay(200);
	   display_stamp_bon(enem1l, x2, y1);
		delay(200);
      if(rev == 3)
			swing_chain(x1, y1);
		}
   display_stamp(blank, x2, y1);
   setcolor(9);
   line(170, 105, 170, 90);
   line(170, 115, 170, 129);
   line(175, 110, 188, 110);
   line(165, 110, 150, 110);
   setcolor(15);
   line(175, 105, 189, 90);
   line(165, 105, 150, 90);
   line(175, 115, 189, 129);
   line(165, 115, 150, 129);
   while(y1 < 300)
		{
   	display_stamp_bon(chard, x1, y1);
      delay(5);
      y1+=4;
      }
   display_stamp(blank, x2, 90);
   display_stamp_bon(chain1, x1, y1);
   for(x2=0; x2 < 150; x2+=4)
   	{
   	display_stamp_bon(enem6r, x2, y1);
      delay(5);
      }
   swing_chain(x1, y1);
   display_stamp(blank, x2, y1);
   display_stamp_bon(enem6l, (x2+300), y1);
   while(y1 < 400)
		{
   	display_stamp_bon(chard, x1, y1);
      delay(5);
      y1+=4;
      }
   display_stamp_bon(enem6d, (x2+300), 300);
   while(x1 < 493)
		{
   	display_stamp_bon(charr, x1, y1);
      delay(5);
      x1+=4;
      }
   display_stamp_bon(enem6r, (x2+300), 300);
   while(y1 > 300)
		{
   	display_stamp_bon(charup, x1, y1);
      delay(5);
      y1-=4;
      }
   swing_chain(x1, y1);
   for(int rev=0; rev < 4; ++rev)
   	{
	   display_stamp_bon(enem6d, (x2+300), 300);
		delay(125);
	   display_stamp_bon(enem6r, (x2+300), 300);
		delay(125);
	   display_stamp_bon(enem6u, (x2+300), 300);
		delay(125);
	   display_stamp_bon(enem6l, (x2+300), 300);
		delay(125);
		}
   display_stamp(blank, (x2 + 300), 300);
   setcolor(9);
   line(470, 315, 470, 300);
   line(470, 325, 470, 337);
   line(475, 320, 488, 320);
   line(465, 320, 450, 320);
   setcolor(15);
   line(475, 315, 489, 300);
   line(465, 315, 450, 300);
   line(475, 325, 489, 337);
   line(465, 325, 450, 337);
   delay(400);
   display_stamp(blank, (x2 + 298), 298);
   while(y1 > 0)
   	{
      display_stamp_bon(charup, x1, y1);
      delay(4);
      y1-=4;
      }
   cleardevice();
   clear_keys();
   setcolor(11);
   settextstyle(10, 0, 7);
   outtextxy(210,10, "SPIEL");
   outtextxy(183,120, "FERTIG");
   for(slot = 0; slot < 12; ++slot)
	   display_stamp(enem2r, 0, (slot * 40));
   for(slot = 1; slot < 16; ++slot)
   	display_stamp(enem3u, (slot * 40), 440);
   for(slot = 10; slot >= 0; --slot)
	   display_stamp(enem4l, 600, (slot * 40));
   for(slot = 14; slot > 0; --slot)
   	display_stamp(enem5d, (slot * 40), 0);
   setcolor(12);
   settextstyle(8, 0, 6);
   outtextxy(46,265, "oberste Spielstand");
   gotoxy(39,23);
   cout<<score;
   ingame = 0;
   getch();
   }

//******************************************************************************************

void swing_chain(int x1, int y1)
	{
   display_stamp_bon(chain2, x1, y1);
   delay(200);
   display_stamp_bon(chain3, x1, y1);
   delay(200);
   display_stamp_bon(chain4, x1, y1);
   delay(200);
   display_stamp_bon(chain3, x1, y1);
   delay(200);
   display_stamp_bon(chain5, x1, y1);
   delay(200);
   display_stamp_bon(chain2, x1, y1);
   delay(200);
   display_stamp_bon(chain1, x1, y1);
   delay(200);
   }

//******************************************************************************************

void select_level()
	{
   cleardevice();
   int madechoice = 0, key;
	level_type = 0;
   level = 1;
   setcolor(14);
   settextstyle(4, 0, 4);
   outtextxy(55, 40, "Welches Stadium wollen Sie spielen?");
   settextstyle(2, 0, 5);
   display_list();
   while(madechoice == 0)
   	{
      if(kbhit())
      	{
         key = getch();
         if(key == 56)
         	{
            if(level_type == 0)
            	level_type = 15;
            else
            	--level_type;
            //up
            }
         else if(key == 50)
         	{
            if(level_type == 15)
            	level_type = 0;
            else
            	++level_type;
            //down
            }
         else if((key == 13) || (key == 32))  	//enter
				madechoice = 1;
         if((key == 50) || (key == 56))
				display_list();
         }
   	}
   cleardevice();
   setcolor(7);
   settextstyle(6, 0, 4);
   outtextxy(60, 40, "sehr leicht");
   outtextxy(320, 320, "sehr schwer");
   setcolor(14);
   settextstyle(4, 0, 4);
   outtextxy(10, 10, "Wie schwer wollen Sie das Stadium sein?");
  	settextstyle(2, 0, 5);
   display_chal();
   madechoice = 0;
   while(madechoice == 0)
   	{
      if(kbhit())
      	{
         key = getch();
         if(key == 56)
         	{
            if(level == 1)
            	level = 20;
            else
            	--level;
            //up
            }
         else if(key == 50)
         	{
            if(level == 20)
            	level = 1;
            else
            	++level;
            //down
            }
         else if((key == 13) || (key == 32))  	//enter
				madechoice = 1;
         if((key == 50) || (key == 56))
				display_chal();
         }
      }
   }

//******************************************************************************************

void display_list()
	{
   setcolor(5);
   outtextxy(230, 120, "maennlichen Hauptwoerter");
   outtextxy(230, 140, "femininen Hauptwoerter");
   outtextxy(230, 160, "saechlichen Hauptwoerter");
   outtextxy(230, 180, "Essen");
   outtextxy(230, 200, "Klamotten");
   outtextxy(230, 220, "um das Haus herum");
   outtextxy(230, 240, "Verben");
   outtextxy(230, 260, "Hauptwoerter");
   outtextxy(230, 280, "Adjektive");
   outtextxy(230, 300, "Staedte in Deutschland");
   outtextxy(230, 320, "Formen von may");
   outtextxy(230, 340, "Formen von should");
   outtextxy(230, 360, "Formen von can");
   outtextxy(230, 380, "Formen von to want");
   outtextxy(230, 400, "Formen von must");
   outtextxy(230, 420, "Formen von to like");
   setcolor(12);
   switch(level_type)
   	{
      case 0:	outtextxy(230, 120, "maennlichen Hauptwoerter");
			      break;
      case 1:	outtextxy(230, 140, "femininen Hauptwoerter");
			      break;
      case 2:	outtextxy(230, 160, "saechlichen Hauptwoerter");
			      break;
      case 3:	outtextxy(230, 180, "Essen");
			      break;
      case 4:	outtextxy(230, 200, "Klamotten");
			      break;
      case 5:	outtextxy(230, 220, "um das Haus herum");
			      break;
      case 6:	outtextxy(230, 240, "Verben");
			      break;
      case 7:	outtextxy(230, 260, "Hauptwoerter");
			      break;
      case 8:	outtextxy(230, 280, "Adjektive");
			      break;
      case 9:	outtextxy(230, 300, "Staedte in Deutschland");
			      break;
      case 10:	outtextxy(230, 320, "Formen von may");
			      break;
      case 11:	outtextxy(230, 340, "Formen von should");
			      break;
      case 12:	outtextxy(230, 360, "Formen von can");
			      break;
      case 13:	outtextxy(230, 380, "Formen von to want");
			      break;
      case 14:	outtextxy(230, 400, "Formen von must");
			      break;
      case 15:	outtextxy(230, 420, "Formen von to like");
      }
   }

//******************************************************************************************

void display_chal()
	{
   setcolor(2);
   outtextxy(230, 50, "Eins");
   outtextxy(230, 65, "Zwei");
   outtextxy(230, 80, "Drei");
   outtextxy(230, 95, "Vier");
   outtextxy(230, 110, "Fuenf");
   outtextxy(230, 125, "Sechs");
   outtextxy(230, 140, "Sieben");
   outtextxy(230, 155, "Acht");
   outtextxy(230, 170, "Neun");
   outtextxy(230, 185, "Zehn");
   outtextxy(230, 200, "Elf");
   outtextxy(230, 215, "Zwoelf");
   outtextxy(230, 230, "Dreizehn");
   outtextxy(230, 245, "Vierzehn");
   outtextxy(230, 260, "Fuenfzehn");
   outtextxy(230, 275, "Sechzehn");
   outtextxy(230, 290, "Siebzehn");
   outtextxy(230, 305, "Achtzehn");
   outtextxy(230, 320, "Neunzehn");
   outtextxy(230, 335, "Zwanzig");
   setcolor(10);
   switch(level)
   	{
      case 1:	outtextxy(230, 50, "Eins");
			      break;
      case 2:	outtextxy(230, 65, "Zwei");
			      break;
      case 3:	outtextxy(230, 80, "Drei");
			      break;
      case 4:	outtextxy(230, 95, "Vier");
			      break;
      case 5:	outtextxy(230, 110, "Fuenf");
			      break;
      case 6:	outtextxy(230, 125, "Sechs");
			      break;
		case 7:	outtextxy(230, 140, "Sieben");
			      break;
   	case 8:	outtextxy(230, 155, "Acht");
			      break;
		case 9:  outtextxy(230, 170, "Neun");
			      break;
   	case 10:	outtextxy(230, 185, "Zehn");
			      break;
   	case 11:	outtextxy(230, 200, "Elf");
			      break;
   	case 12:	outtextxy(230, 215, "Zwoelf");
			      break;
   	case 13:	outtextxy(230, 230, "Dreizehn");
			      break;
   	case 14:	outtextxy(230, 245, "Vierzehn");
			      break;
   	case 15:	outtextxy(230, 260, "Fuenfzehn");
			      break;
   	case 16:	outtextxy(230, 275, "Sechzehn");
			      break;
   	case 17:	outtextxy(230, 290, "Siebzehn");
			      break;
   	case 18:	outtextxy(230, 305, "Achtzehn");
			      break;
   	case 19:	outtextxy(230, 320, "Neunzehn");
			      break;
   	case 20:	outtextxy(230, 335, "Zwanzig");
      }
	}
