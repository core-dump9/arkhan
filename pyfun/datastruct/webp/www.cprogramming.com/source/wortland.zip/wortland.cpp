//****************************************
//***Project Codename: wortland***********
//****************************************
//******************************************************************************
//*********************Axels Abenteuer in Wortland***************************
//******************************************************************************
//Created By: Ryan A. Lloyd, Wonder Workers C.E.O.
//Date Started: 4/26/01
//Date of Completion: 5/25/01

//!!!!!Important!!!!!
//For the game to work properly, all of the files that came with the project must
//be in the same directory.  In addition, the path to the game must exist on a
//drive, such as the hard drive, that can be written to freely.  Storing the files
//on a floppy disk or CD will slow the game and disrupt saving routines.


//Check out Wonder Workers' Programming Webpage at:
//							  http://www.geocities.com/wonworkers/main.html

//Feel free to e-mail Wonder Workers at:
//							  wonderworkers@excite.com


// I N C L U D E S ///////////////////////////////////////////////////////////

#include <conio.h>
#include <iostream.h>
#include <fstream.h>
#include <stdio.h>
#include <process.h>
#include <alloc.h>
#include <dos.h>
#include <mem.h>
#include "apstring.h"
#include "apmatrix.cpp"
#include <graphics.h>
#include <time.h>
#include "wortfcpg.h"


//**************************************************************************
//*******************Main Driver Begins Below*******************************
//**************************************************************************

int main()
  	{
   time_t plague;
	time(&plague);
	srand((unsigned int)plague);
	Video_Mode(MODE13H);
   int newpath, keycode;
   int flashstage = 1;
   int finishgame;
   int etype, estart, randrow, randcol, randside, newslot;
   long int enemycount, erefresh_count;
   int x1, x2, y1, y2;
   apstring ehit;
   int newword;
   long int origscore;
   int inbank;
   apstring wantsym;
   load_files();
   while(inapp == 1)
   	{
   	newpath = title_screen();
      if((ingame == 1) && (inapp == 1))
      	{
         score = 0;
         finishgame = 0;
         level = 1;
         if(newpath == 1)
         	select_level();
         cleardevice();
         if((newpath == 0) || (newpath == 1))
         	{
            lives = 3;
            while((finishgame == 0) && (inapp == 1) && (ingame == 1))
            	{
               cleardevice();
            	setcolor(13);
            	settextstyle(9, 0, 4);
               outtextxy(133, 150, "Stadium");
               switch (level)
               	{
                  case 1:	outtextxy(340, 150, "Eins");
                  			break;
                  case 2:  outtextxy(340, 150, "Zwei");
			                  break;
                  case 3:  outtextxy(340, 150, "Drei");
         			         break;
                  case 4:  outtextxy(340, 150, "Vier");
                  			break;
                  case 5:  outtextxy(340, 150, "Fuenf");
			                  break;
                  case 6:  outtextxy(340, 150, "Sechs");
         			         break;
                  case 7:  outtextxy(340, 150, "Sieben");
			                  break;
                  case 8:  outtextxy(340, 150, "Acht");
         			         break;
                  case 9:  outtextxy(340, 150, "Neun");
			                  break;
                  case 10:	outtextxy(340, 150, "Zehn");
         			         break;
                  case 11:	outtextxy(340, 150, "Elf");
                  			break;
                  case 12:	outtextxy(340, 150, "Zwoelf");
			                  break;
                  case 13:	outtextxy(340, 150, "Dreizehn");
         			         break;
                  case 14:	outtextxy(340, 150, "Vierzehn");
                  			break;
                  case 15:	outtextxy(340, 150, "Fuenfzehn");
			                  break;
                  case 16:	outtextxy(340, 150, "Sechzehn");
         			         break;
                  case 17:	outtextxy(340, 150, "Siebzehn");
                  			break;
                  case 18:	outtextxy(340, 150, "Achtzehn");
			                  break;
                  case 19:	outtextxy(340, 150, "Neunzehn");
         			         break;
                  case 20:	outtextxy(340, 150, "Zwanzig");
                  }
	            settextstyle(9, 0, 3);
   	         setcolor(10);
      	      outtextxy(40, 35, "Landkarte laedt . . .");
         	   settextstyle(3, 0, 4);
            	setcolor(3);
	            outtextxy(5, 270, "Stadiumtyp:");
   	         if(newpath == 0)
      	         level_type = (rand() % 16);
         	   switch(level_type)
            		{
               	case 0:	outtextxy(200, 270, "maennlichen Hauptwoerter");
               				load_map("gendbend.map");
                     	   wantsym = "m";
                        	break;
	               case 1:  outtextxy(200, 270, "femininen Hauptwoerter");
				               load_map("gendbend.map");
      	   			      wantsym = "f";
         	      			break;
            	   case 2:  outtextxy(200, 270, "saechlichen Hauptwoerter");
               				load_map("gendbend.map");
                  	      wantsym = "n";
                  			break;
	               case 3:  outtextxy(200, 270, "Essen");
   	               		load_map("cats4.map");
      	                  wantsym = "d";
         	         		break;
            	   case 4:  outtextxy(200, 270, "Klamotten");
               	   		load_map("cats4.map");
                  	      wantsym = "c";
                  			break;
   	            case 5:  outtextxy(200, 270, "um das Haus herum");
                  			load_map("cats4.map");
         	               wantsym = "f";
            	            break;
               	case 6:  outtextxy(200, 270, "Verben");
                  			load_map("endings.map");
                     	   wantsym = "v";
                        	break;
	               case 7:  outtextxy(200, 270, "Hauptwoerter");
   	               		load_map("endings.map");
      	                  wantsym = "n";
         	               break;
            	   case 8:  outtextxy(200, 270, "Adjektive");
               	   		load_map("endings.map");
                  	      wantsym = "a";
                     	   break;
	               case 9:  outtextxy(200, 270, "Staedte in Deutschland");
   	               		load_map("cities.map");
      	                  wantsym = "g";
         	               break;
            	   case 10: outtextxy(200, 270, "Formen von \"may\"");
               	   		load_map("modals.map");
                  	      wantsym = "d";
	                        break;
   	            case 11: outtextxy(200, 270, "Formen von \"should\"");
      	            		load_map("modals.map");
         	               wantsym = "s";
            	            break;
               	case 12:	outtextxy(200, 270, "Formen von \"can\"");
	                  		load_map("modals.map");
   	                     wantsym = "k";
      	                  break;
         	      case 13: outtextxy(200, 270, "Formen von \"to want\"");
            	      		load_map("modals.map");
               	         wantsym = "w";
                  	      break;
	               case 14: outtextxy(200, 270, "Formen von \"must\"");
   	               		load_map("modals.map");
      	                  wantsym = "y";
         	               break;
            	   case 15: outtextxy(200, 270, "Formen von \"to like\"");
               	   		load_map("modals.map");
                  	      wantsym = "m";
	               }
   	         settextstyle(9, 0, 3);
      	      setcolor(10);
         	   outtextxy(450, 35, "fertig");
            	settextstyle(8, 0, 4);
	            while(! kbhit())
   	         	{
      	         if(flashstage == 1)
         	      	{
            	      flashstage = 2;
               	   setcolor(1);
                  	}
	               else
   	            	{
      	            flashstage = 1;
         	         setcolor(4);
                     }
	               outtextxy(10, 410, "Druecken Sie <Enter> zu beginnen!");
   	            delay(150);
      	         }
         	   getch();
	            finishlevel = 0;
   	         chardir = 1;
      	      char_row = 3;
         	   char_col = 2;
            	enemycount = 0;
	            numenem = 0;
   	         erefresh_count=0;
      	      bonus = 1;
         	   for(int r=0; r < map_rows; ++r)
            	 	for(int c=0; c < map_cols; ++c)
               	  	cemap[r][c] = 0;
	            for(int i=0; i < 10; ++i)
   	           	enemies[i].on = 0;
      	      cemap[3][2] = 100;
         	   wordsleft = (10 + level);
            	cleardevice();
	            setcolor(10);
   	         for(int r=0; r < (map_rows + 1); ++r)
      	      	line(10, (10 + r * 50), 550, (10 + r * 50));
         	   for(int c=0; c < (map_cols + 1); ++c)
            		line((10 + c * 90), 10, (10 + c * 90), 360);
	            setcolor(5);
   	         rectangle(9, 9, 551, 361);
      	      rectangle(7, 7, 553, 363);
         	   rectangle(5, 5, 555, 365);
            	rectangle(3, 3, 557, 367);
	            rectangle(1, 1, 559, 369);
   	         setcolor(14);
      	      settextstyle(2, 0, 11);
         	   outtextxy(20, 420, "aufgeben");
            	outtextxy(270, 420, "zurueckkehren");
	            draw_pause_bars();
   	         setcolor(13);
      	      settextstyle(10, 0, 1);
         	   outtextxy(18, 367, "Punkte:");
            	outtextxy(240, 370, "Spiel:");
	            settextstyle(1, 0, 3);
               switch(level_type)
         	   	{
            	   case 0:	outtextxy(340, 380, "maennlichen Hauptwoerter");
               				break;
	               case 1:  outtextxy(340, 380, "femininen Hauptwoerter");
   	               		break;
      	         case 2:  outtextxy(340, 380, "saechlichen Hauptwoerter");
         	         		break;
            	   case 3:  outtextxy(340, 380, "Essen");
	                  		break;
   	            case 4:  outtextxy(340, 380, "Klamotten");
      	            		break;
         	      case 5:  outtextxy(340, 380, "um das Haus herum");
            	      		break;
	               case 6:  outtextxy(340, 380, "Verben");
   	               		break;
      	         case 7:  outtextxy(340, 380, "Hauptwoerter");
         	         		break;
            	   case 8:  outtextxy(340, 380, "Adjektive");
	                  		break;
   	            case 9:  outtextxy(340, 380, "Staedte in Deutschland");
      	                  break;
         	      case 10: outtextxy(340, 380, "Formen von \"may\"");
            	            break;
               	case 11: outtextxy(340, 380, "Formen von \"should\"");
                  	      break;
	               case 12: outtextxy(340, 380, "Formen von \"can\"");
   	                     break;
      	         case 13: outtextxy(340, 380, "Formen von \"to want\"");
         	               break;
            	   case 14: outtextxy(340, 380, "Formen von \"must\"");
               	         break;
	               case 15:	outtextxy(340, 380, "Formen von \"to like\"");
   	            }
      	      outtextxy(575, 20, "Leben:");
         	   settextstyle(1, 0, 2);
            	outtextxy(565, 100, "Woerter");
	            outtextxy(565, 125, "bleiben:");
   	         settextstyle(1, 0, 1);
      	      outtextxy(565, 210, "STADIUM:");
         	   display_score();
            	display_lives();
	            display_words();
   	         display_level();
      	      display_map();
         	   while((inapp == 1) && (finishlevel == 0) && (ingame == 1))
            		{
	               //refreshing
   	            if((enemycount > rel_hounds) && (numenem < 9))
      	         	{
         	         for(int index=0; index < 10; ++index)
            	      	if(enemies[index].on == 0)
               	      	newslot = index;
	                  etype = rand() % 1000;
   	               switch(level)
      	            	{
         	            case 1:	if(etype >=0 && etype <= 900)
   	                    				enemies[newslot].type = 1;
	   	                 			else if(etype > 901 && etype <= 950)
         	                     	enemies[newslot].type = 2;
            	                  else
               	               	enemies[newslot].type = 3;
                  	            break;
                     	case 2:	if(etype >=0 && etype <= 800)
	                        	  		enemies[newslot].type = 1;
   	                  			else if(etype > 801 && etype <= 950)
      	                          	enemies[newslot].type = 2;
         	                     else
            	                    	enemies[newslot].type = 3;
               	               break;
	                     case 3:	if(etype >=0 && etype <= 700)
   	                     	  		enemies[newslot].type = 1;
      	                  	  	else if(etype > 701 && etype <= 950)
         	                       	enemies[newslot].type = 2;
            	                  else
	                                	enemies[newslot].type = 3;
   	                           break;
      	               case 4:	if(etype >=0 && etype <= 600)
	         	              			enemies[newslot].type = 1;
            	            		else if(etype > 601 && etype <= 950)
   	                             	enemies[newslot].type = 2;
      	                        else
         	                       	enemies[newslot].type = 3;
            	                  break;
               	      case 5:	if(etype >=0 && etype <= 500)
                  	      			enemies[newslot].type = 1;
	                        		else if(etype > 501 && etype <= 950)
   	                             	enemies[newslot].type = 2;
      	                        else
         	                       	enemies[newslot].type = 3;
            	                  break;
	                     case 6:	if(etype >=0 && etype <= 400)
   	                     			enemies[newslot].type = 1;
      	                  		else if(etype > 401 && etype <= 850)
         	                       	enemies[newslot].type = 2;
            	                  else
                                  	enemies[newslot].type = 3;
                                 break;
   	                  case 7:	if(etype >=0 && etype <= 300)
        	                  			enemies[newslot].type = 1;
  	   	                   		else if(etype > 301 && etype <= 750)
   	                             	enemies[newslot].type = 2;
         	                     else
            	                    	enemies[newslot].type = 3;
               	               break;
                  	   case 8:	if(etype >=0 && etype <= 200)
	                        			enemies[newslot].type = 1;
   	                     		else if(etype > 201 && etype <= 650)
      	                          	enemies[newslot].type = 2;
         	                     else
            	                    	enemies[newslot].type = 3;
               	               break;
                  	   case 9:	if(etype >=0 && etype <= 100)
                     	   			enemies[newslot].type = 1;
                        			else if(etype > 101 && etype <= 550)
                           	     	enemies[newslot].type = 2;
                              	else
                                		enemies[newslot].type = 3;
	                              break;
   	                  case 10:	if(etype >=0 && etype <= 500)
      	                  			enemies[newslot].type = 3;
         	               		else if(etype > 501 && etype <= 950)
            	                    	enemies[newslot].type = 4;
               	               else
                  	             	enemies[newslot].type = 5;
                     	         break;
	                     case 11:	if(etype >=0 && etype <= 400)
   	                     			enemies[newslot].type = 3;
      	                  		else if(etype > 401 && etype <= 850)
         	                       	enemies[newslot].type = 4;
            	                  else
               	                 	enemies[newslot].type = 5;
                  	            break;
                     	case 12:	if(etype >=0 && etype <= 350)
                       					enemies[newslot].type = 3;
                       				else if(etype > 351 && etype <= 700)
		                            	enemies[newslot].type = 4;
      		                     else
              	                    	enemies[newslot].type = 5;
                 		            break;
	                     case 13:	if(etype >=0 && etype <= 300)
   	                     			enemies[newslot].type = 3;
              		           		else if(etype > 301 && etype <= 650)
                   	             	enemies[newslot].type = 4;
                     	         else
                        	        	enemies[newslot].type = 5;
                           	   break;
	                     case 14:	if(etype >=0 && etype <= 250)
   	                     			enemies[newslot].type = 3;
      	                  		else if(etype > 251 && etype <= 600)
         	                       	enemies[newslot].type = 4;
            	                  else
               	                 	enemies[newslot].type = 5;
                  	            break;
                     	case 15:	if(etype >=0 && etype <= 225)
                        				enemies[newslot].type = 3;
                        			else if(etype > 226 && etype <= 575)
                              	  	enemies[newslot].type = 4;
	                              else
   	                             	enemies[newslot].type = 5;
      	                        break;
         	            case 16:	if(etype >=0 && etype <= 200)
            	            			enemies[newslot].type = 3;
               	         		else if(etype > 201 && etype <= 550)
                  	              	enemies[newslot].type = 4;
                     	         else
                        	       	enemies[newslot].type = 5;
                           	   break;
	                     case 17:	if(etype >=0 && etype <= 170)
                        				enemies[newslot].type = 3;
	                        		else if(etype > 171 && etype <= 500)
   	                             	enemies[newslot].type = 4;
      	                        else
         	                       	enemies[newslot].type = 5;
            	                  break;
               	      case 18:	if(etype >=0 && etype <= 100)
                  	      			enemies[newslot].type = 3;
                     	   		else if(etype > 101 && etype <= 400)
                        	        	enemies[newslot].type = 4;
                           	   else if(etype > 401 && etype <= 900)
                              	  	enemies[newslot].type = 5;
	                              else
   	                             	enemies[newslot].type = 6;
      	                        break;
         	            case 19:	if(etype >=0 && etype <= 50)
            	            			enemies[newslot].type = 3;
               	         		else if(etype > 51 && etype <= 300)
                  	              	enemies[newslot].type = 4;
                     	         else if(etype > 301 && etype <= 800)
                        	        	enemies[newslot].type = 5;
                           	   else
                              	  	enemies[newslot].type = 6;
	                              break;
   	                  case 20:	if(etype >=0 && etype <= 200)
      	                  			enemies[newslot].type = 4;
         	                     else if(etype > 201 && etype <= 750)
            	                    	enemies[newslot].type = 5;
               	               else
                  	              	enemies[newslot].type = 6;
                     	}
	                  if(enemies[newslot].type == 3)
   	                 	enemies[newslot].moves = 8;
      	            else if(enemies[newslot].type == 4)
         	           	enemies[newslot].moves = 9;
            	      else if(enemies[newslot].type == 5)
               	     	enemies[newslot].moves = 10;
                  	else if(enemies[newslot].type == 6)
	                    	enemies[newslot].moves = 7;
   	               randside = rand() % 2;
      	            estart = rand() % 2;
         	         if(estart == 1)
               	    	{
            	         randrow = rand() % 7;
                  	   enemies[newslot].row = randrow;
		                  enemies[newslot].col = (randside * 5);
  		                  if(randside == 0)
      	               	{
         	               cemap[enemies[newslot].row][enemies[newslot].col] = ((enemies[newslot].type + 1) * 100);
            	            enemies[newslot].dir = 1;
               	         }
                  	   else
                     		{
                        	cemap[enemies[newslot].row][enemies[newslot].col] = ((enemies[newslot].type + 1) * 100) + 1;
	                        enemies[newslot].dir = 2;
   	                     }
      	               }
         	         else
	                  	{
   	                  randcol = rand() % 6;
      	               enemies[newslot].row = (randside * 6);
         	            enemies[newslot].col = randcol;
            	         if(randside == 0)
               	      	{
	                        cemap[enemies[newslot].row][enemies[newslot].col] = ((enemies[newslot].type + 1) * 100) + 3;
   	                     enemies[newslot].dir = 4;
      	                  }
         	            else
            	         	{
               	         cemap[enemies[newslot].row][enemies[newslot].col] = ((enemies[newslot].type + 1) * 100) + 2;
                  	      enemies[newslot].dir = 3;
                     	   }
	                     }
   	               enemies[newslot].on = 1;
      	            ++numenem;
         	         enemycount = 0;
            	      display_map();
               	   }
	               if(kbhit())
   	            	{
      	            keycode = getch();
         	         if((keycode == 27) || (keycode == 80) || (keycode == 112))     //Pause OR Main Menu
            	      	pause();
               	   else if((keycode >= 50) && (keycode <= 56))
	                  	{
   	                  if((keycode == 56) && (char_row > 0))
      	               	{
         	               display_stamp(blank, (char_col * 95 + 15), (char_row * 50 + 15));
            	            cemap[char_row][char_col] = 0;
               	         --char_row;
                  	      chardir=3;
                     	   if(cemap[char_row][char_col] != 0)
	                        	hit_enemy(-1);
   	                     else
      	                  	{
         	                  cemap[char_row][char_col] = 102;
            	               display_map();
               	            }
                  	      //up
	                        }
   	                  else if((keycode == 50) && (char_row < (map_rows - 1)))
      	               	{
         	               display_stamp(blank, (char_col * 95 + 15), (char_row * 50 + 15));
            	            cemap[char_row][char_col] = 0;
               	         ++char_row;
                  	      chardir=4;
                     	   if(cemap[char_row][char_col] != 0)
	                        	hit_enemy(-1);
   	                     else
      	                  	{
         	                  cemap[char_row][char_col] = 103;
            	               display_map();
               	            }
                  	      display_map();
	                        //down
   	                     }
      	               else if((keycode == 54) && (char_col < (map_cols - 1)))
         	            	{
            	            display_stamp(blank, (char_col * 95 + 15), (char_row * 50 + 15));
               	         cemap[char_row][char_col] = 0;
                  	      ++char_col;
                     	   chardir=1;
                        	if(cemap[char_row][char_col] != 0)
	                        	hit_enemy(-1);
   	                     else
      	                  	{
         	                  cemap[char_row][char_col] = 100;
            	               display_map();
               	            }
                  	      //right
                     	   }
	                     else if((keycode == 52) && (char_col > 0))
   	                  	{
      	                  display_stamp(blank, (char_col * 95 + 15), (char_row * 50 + 15));
         	               cemap[char_row][char_col] = 0;
            	            --char_col;
               	         chardir=2;
                  	      if(cemap[char_row][char_col] != 0)
                     	   	hit_enemy(-1);
                        	else
	                        	{
   	                        cemap[char_row][char_col] = 101;
      	                     display_map();
         	                  }
            	            //left
               	         }
                  	   }
	                  else if(keycode == 32)
   	               	{
      	               origscore = score;
         	            ehit = map[((char_row * 6) + char_col)][1];
            	         if(((level_type == 0) && (ehit == "m")) || ((level_type == 1) && (ehit == "f")) || ((level_type == 2) && (ehit == "n")))
               	      	{
                  	      score+=100;
                     	   hit_word();
                        	}
	                     else if(((level_type == 3) && (ehit == "d")) || ((level_type == 4) && (ehit == "c")) || ((level_type == 5) && (ehit == "f")))
   	                  	{
      	                  score+=85;
         	               hit_word();
            	            }
               	      else if(((level_type == 6) && (ehit == "v")) || ((level_type == 7) && (ehit == "n")) || ((level_type == 8) && (ehit == "a")))
                  	   	{
                     	   score+=70;
                        	hit_word();
	                        }
   	                  else if((level_type == 9) && (ehit == "g"))
      	               	{
         	               score+=200;
            	            hit_word();
               	         }
                  	   else if(((level_type == 10) && (ehit == "d")) || ((level_type == 11) && (ehit == "s")) || ((level_type == 12) && (ehit == "k")) || ((level_type == 13) && (ehit == "w")) || ((level_type == 14) && (ehit == "y")) || ((level_type == 15) && (ehit == "m")))
	                     	{
   	                     score+=80;
      	                  hit_word();
         	               }
            	         else
               	         {
                  	      bonus = 0;
                     	   popup_wrong(((char_row * 6) + char_col));
                        	}
	                     if((origscore < 10000) && (score >= 10000))
   	                  	{
      	                  ++lives;
         	               display_lives();
            	            }
                        if(finishlevel == 1)
                        	{
                           if((level == 20) || (newpath == 1))
         							finishgame = 1;
                           }
               	      else
                  	   	{
                     	   if((level_type >= 0) && (level_type <= 2))
                        		newword = (rand() % 273);
	                        else if((level_type >= 3) && (level_type <= 5))
   	                     	newword = (rand() % 219);
      	                  else if((level_type >= 6) && (level_type <= 8))
         	                  newword = (rand() % 143);
            	            else if(level_type == 9)
						  				newword = (rand() % 127);
                  	      else
	                  	      newword = (rand() % 75);
		                     map[((char_row * 6) + char_col)][0] = allwords[newword][0];
   		                  map[((char_row * 6) + char_col)][1] = allwords[newword][1];
      		               map[((char_row * 6) + char_col)][2] = allwords[newword][2];                        inbank=0;
         		            for(int k=0; (k < (map_rows * map_cols)) && (inbank == 0); ++k)
            		         	if(map[k][1] == wantsym)
               		         	inbank = 1;
                  		   if(inbank == 0)
                     			{
                        		int i;
		                        for(i=0; allwords[i][1] != wantsym; ++i);
   		                     newword=i;
      		                  map[((char_row * 6) + char_col)][0] = allwords[newword][0];
         		               map[((char_row * 6) + char_col)][1] = allwords[newword][1];
            		            map[((char_row * 6) + char_col)][2] = allwords[newword][2];
               		         }
                  		   setcolor(0);
                     		for(x1 = (char_col * 90 + 11), y1 = (char_row * 50 + 12), x2 = (char_col * 90 + 96), y2 = (char_row * 50 + 58); x1 < (char_col * 90 + 54); ++x1, ++y1, --x2, --y2)
                     			rectangle(x1, y1, x2, y2);
		                     display_map();
                           }
   	                  //space bar
      	               }
         	         }
            	   if(erefresh_count > (erefresh - (37 * (level - 1))))
               		{
                  	update_enem();
	                  erefresh_count = 0;
   	               }
      	         ++erefresh_count;
         	      ++enemycount;
            	   delay(1);
               	}
	            ++level;
   	         }
      	   if(finishgame == 1)
            	game_complete();
	         }
   	  	}
      }
   cleardevice();
  	setcolor(11);
 	settextstyle(3,0,4);
	outtextxy(50, 90, "Final German Project--Ryan Lloyd");
	setcolor(2);
	settextstyle(10,0,6);
	outtextxy(0, 300, "Copyright 2001");
  	getch();
	Video_Mode(TEXT_MODE);
   return 0;
	}
//Main Driver Ends
