This is a Wormgame made by Kalle Perfekt.

To compile do this:
Link masken.cpp , worm.cpp , point.cpp
