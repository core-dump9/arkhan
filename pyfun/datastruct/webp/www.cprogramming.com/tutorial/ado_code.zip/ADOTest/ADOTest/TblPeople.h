// <copyright file="tblpeople.h" company="Mancier Connections">
// Copyright (c) 2009 All Right Reserved
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// </copyright>
// <author>Patrick Mancier</author>
// <email>teknerd001@gmail.com</email>
// <date>2009-03-21</date>
// <summary>Header file for CTblPeople class</summary>
#pragma once

#include "adomanager.h"

class CTblPeople :	public CADOManager
{
private:

	void Initialize();

public:
	int mp_iidRecord;			//	Parameter: RecordID to operate on (mp = parameter class value)
	CString m_szPersonName;		//	Persons full name
	int m_iPersonAge;			//	Persons age

	void SetDELETEParameters();	// NOT USED
	void SetINSERTParameters();
	void SetSELECTParameters();
	void SetUPDATEParameters();	

	//	Virtual functions for getting the values in the recordset from a query
	void GetSELECTValues();

	CTblPeople(CADOConnection& dbc);
	CTblPeople(CADOConnection *pdbc);
	CTblPeople(void);
	~CTblPeople(void);
};
