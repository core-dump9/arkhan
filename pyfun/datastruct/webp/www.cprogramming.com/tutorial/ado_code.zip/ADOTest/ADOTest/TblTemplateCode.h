// <copyright file="tbltemplatecode.h" company="Mancier Connections">
// Copyright (c) 2009 All Right Reserved
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY 
// KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// </copyright>
// <author>Patrick Mancier</author>
// <email>teknerd001@gmail.com</email>
// <date>2009-03-21</date>
// <summary>A table class 'template' (not programming template) to use to quickly create a table class</summary>
#pragma once

#include "adointerface.h"

class CTbl<TableName> :	public CADOInterface
{
private:
	void Initialize();

public:
	//	Put column class members here

	//	Only override the functions you need here
	void SetUserParameters();
	void SetDELETEParameters();
	void SetINSERTParameters();
	void SetSELECTParameters();
	void SetUPDATEParameters();

	void GetUserValues();
	void GetSELECTValues();

	CTbl<TableName>(CADOConnection *pdbc);
	CTbl<TableName>(void);
	~CTbl<TableName>(void);
};
