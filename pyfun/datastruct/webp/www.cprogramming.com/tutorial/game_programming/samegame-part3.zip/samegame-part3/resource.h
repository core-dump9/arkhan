//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SameGame.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SameGameTYPE                129
#define ID_EDIT_REDO32771               32771
#define ID_LEVEL_3COLORS                32772
#define ID_LEVEL_4COLORS                32773
#define ID_LEVEL_5COLORS                32774
#define ID_LEVEL_6COLORS                32775
#define ID_LEVEL_7COLORS                32776
#define ID_SETUP_EDITBLOCKSIZE          32777
#define ID_SETUP_EDITBLOCKCOUNT         32778
#define ID_SETUP_EDITCOLORS             32779
#define ID_SETUP_BLOCKSIZE              32780
#define ID_SETUP_BLOCKCOUNT             32781
#define ID_SETUP_COLORS                 32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
