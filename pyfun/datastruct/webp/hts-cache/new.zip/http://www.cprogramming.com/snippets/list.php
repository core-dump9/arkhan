
<html>
<head>
<link rel="alternate" type="application/rss+xml" title="RSS" href="http://feeds2.feedburner.com/Cprogrammingcom/">
<link rel="stylesheet" href="http://static.cprogramming.com/main_images/style.css?np9" type="text/css">
<!--[if IE]>
    <link rel="stylesheet" href="http://static.cprogramming.com/main_images/style-ie.css?np4" type="text/css">
<![endif]-->



<META NAME="Description" CONTENT="Pick up snippets of C and C++ source code for your own programs or to learn from.">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>C/C++ Source Code Snippets - Cprogramming.com</title>

<!-- ADDED DFP -->
<script type='text/javascript' src='http://partner.googleadservices.com/gampad/google_service.js'>
</script>
<script type='text/javascript'>
GS_googleAddAdSenseService("ca-pub-2560316224908115");
GS_googleEnableAllServices();
</script>
<script type='text/javascript'>
GA_googleAddSlot("ca-pub-2560316224908115", "RunOfSite_LargeRectangle_ATF_336x280");
GA_googleAddSlot("ca-pub-2560316224908115", "RunOfSite_ATF_leaderboard_728x90");

</script>
<script type='text/javascript'>
GA_googleFetchAds();
</script>
<!-- END ADDED DFP -->


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-7820175-1']);
  _gaq.push(['_setDomainName', '.cprogramming.com']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>


</head>


<body>
<div>

<a href="http://www.cprogramming.com/"><img class="logo noprint" src="http://static.cprogramming.com/main_images/title.png" width="324" height="83" border="0"></a> 

<table class="line noprint"><tr><td></td></tr></table>
<div class="noprint" align="right" style="padding-top:25px;padding-right:25px;">
<!-- SiteSearch Google -->
<form action="http://www.google.com/cse" id="cse-search-box">
  <div>
    <input type="hidden" name="cx" value="partner-pub-2560316224908115:wqvdce-aw4a" />
    <input type="hidden" name="ie" value="ISO-8859-1" />
    <input type="text" name="q" size="31" />
    <input type="submit" name="sa" value="Search" />
  </div>
</form>
<script type="text/javascript" src="http://www.google.com/cse/brand?form=cse-search-box&amp;lang=en"></script>
<!-- SiteSearch Google -->
</div>
<div>
  <table class="main">
    <tr>

  	<td class="noprint" colspan="5" bgcolor="#EBEBEB">
  		<img src="http://static.cprogramming.com/main_images/spacer-vert.png" height="6" width="0">
  	   <center>
    	<div class="leaderboard">

<!-- ADDED DFP -->
<!-- ca-pub-2560316224908115/Homepage_ATF_leaderboard_728x90 -->
<script type='text/javascript'>
GA_googleFillSlot("RunOfSite_ATF_leaderboard_728x90");
</script>
<!-- END ADDED DFP -->

</div>
		</center>
		<img src="http://static.cprogramming.com/main_images/spacer-vert.png" height="4" width="1">
  	</td>
        
  </tr>

  <tr>

     <td class="noprint" width="130" valign="top" bgcolor="#EBEBEB"> 
     <div class="menu" valign="top" style="font-size:14px;width:200px">
     <p class="navcategory" align="left">
          <img class="bullet" src="http://static.cprogramming.com/main_images/bullet.gif" width="11" height="14">    Starting out
     </p>

     <p class="navlist" align="left" style="font-size:14px;">
             <a href="http://www.cprogramming.com/c++book/?inl=sb">Get the Ebook</a><br>
             <a href="http://www.cprogramming.com/begin.html">Get Started with C or C++</a><br>
             <a href="http://www.cprogramming.com/compilers.html">Getting a Compiler</a><br>
             <a href="http://www.cprogramming.com/books.html">Book Recommendations</a><br>
     </p>

     <p class="navcategory" align="left">
          <br>
          <img class="bullet" src="http://static.cprogramming.com/main_images/bullet.gif" width="11" height="14"> Tutorials
     </p>

     <p class="navlist" align="left" style="font-size:14px;">
            <a href=http://www.cprogramming.com/tutorial/c-tutorial.html>C Tutorial</a><br>
            <a href=http://www.cprogramming.com/tutorial/c++-tutorial.html>C++ Tutorial</a><br>
            <a href=http://www.cprogramming.com/java-programming.html>Java Tutorial</a><br>
            <a href=http://www.cprogramming.com/game-programming.html>Game Programming</a><br>
            <a href=http://www.cprogramming.com/graphics-programming.html>Graphics Programming</a><br>
            <a href=http://www.cprogramming.com/algorithms-and-data-structures.html>Algorithms &amp; Data Structures</a><br>
            <a href=http://www.cprogramming.com/debuggers.html>Debugging</a><br>
            <a href="http://www.cprogramming.com/tutorial.html">All Tutorials</a><br>
     </p>

     <p class="navcategory" align="left">
          <br>
          <img class="bullet" src="http://static.cprogramming.com/main_images/bullet.gif" width="11" height="14"> Practice
     </p>

     <p class="navlist" align="left" style="font-size:14px;">
            <a href="http://www.cprogramming.com/challenge.html">Practice Problems</a><br>
            <a href="http://www.cprogramming.com/quiz/">Quizzes</a><br>
     </p>
     <p class="navcategory" align="left">
          <br>
          <img class="bullet" src="http://static.cprogramming.com/main_images/bullet.gif" width="11" height="14"> Resources
     </p>

     <p class="navlist" align="left" style="font-size:14px;">
            <a href="http://www.cprogramming.com/cgi-bin/source/source.cgi">Source Code</a><br>
            <a href=http://www.cprogramming.com/snippets/>Source Code Snippets</a><br>
            <a href="http://www.cprogramming.com/tips/">C and C++ Tips</a><br>
            <a href=http://www.cprogramming.com/jobs/>Finding a Job</a>
     </p>

     <p class="navcategory" align="left">
          <br>
          <img class="bullet" src="http://static.cprogramming.com/main_images/bullet.gif" width="11" height="14"> References
     </p>

     <p class="navlist" align="left" style="font-size:14px;">
            <a href="http://www.cprogramming.com/function.html">Function Reference</a><br>
            <a href="http://www.cprogramming.com/reference/">Syntax Reference</a><br>
            <a href="http://www.cprogramming.com/cgi-bin/cdir/Cdirectory.cgi">Programming Links</a><br>
            <a href="http://faq.cprogramming.com/cgi-bin/smartfaq.cgi">Programming FAQ</a><br>
     </p>

     <p class="navcategory" align="left">
          <br>
          <img class="bullet" src="http://static.cprogramming.com/main_images/bullet.gif" width="11" height="14"> Getting Help
     </p>

     <p class="navlist" align="left" style="font-size:14px;">
             <a href="http://www.cprogramming.com/board.html">Message Board</a><br>
             <a href="http://www.cprogramming.com/expert.html">Ask an Expert</a><br>
             <a href="http://www.cprogramming.com/email.html">Email</a><br>
             <a href="http://www.cprogramming.com/about.html">About Us</a>
     </p>
     </div>

<center>
      <br><br>
     <script type="text/javascript"><!--
     google_ad_client = "pub-2560316224908115";
     google_ad_width = 120;
     google_ad_height = 90;
     google_ad_format = "120x90_0ads_al";
     google_ad_channel ="0800879710";
     google_color_border = "EBEBEB";
     google_color_bg = "EBEBEB";
     google_color_link = "C30000";
     google_color_url = "C30000";
     google_color_text = "000000";
     //--></script>
     <script type="text/javascript"
       src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
       </script>
</center>



    </td>
	<td class="content" valign="top">

    			<div class="content2">

<h1>C and C++ Source Code Snippets</h1>



Welcome to Cprogramming.com's programming code snippet repository.  Peruse the
 archives or add your own snippets for others to use!  (Check the following
 link a better definition of a <a
 href=http://www.cprogramming.com/snippets/whatisasnippet.html>snippet</a>)
 <br><br>
 Sort by clicking on any of the headers.<br><br>
 
 <table border=1 cellspacing=8>
 <tr><td><a
 href=list.php?page=0&count=30&orderBy=tip>Snippet</a></td><td><a
 href=list.php?page=0&count=30&orderBy=author>Author</a></td><td><a
 href=list.php?page=0&count=30&orderBy=language>Language</a></td><td><a
 href=list.php?page=0&count=30&orderBy=platform>Platform</a></td><td><a
 href=list.php?page=0&count=30&orderBy=rating>Rating</a>
 (votes)</td>
<tr><td><a href=source-code/dynamically-initialize-4d-array>dynamically create and initialise 4d array</a></td><td><a href=mailto:graemewp@yahoo.com>G.Watt.Porteous</a>
 </td><td>C</td><td>ANSI</td><td>9.6 (5)</td></tr>
<tr><td><a href=source-code/convert-ntstatus-win32-error>Convert NTSTATUS code to Win32 error</a></td><td><a href=mailto:abbotti@mev.co.uk>Ian Abbott</a>
 </td><td>C or C++</td><td>Windows</td><td>9.2 (10)</td></tr>
<tr><td><a href=source-code/view-format-IEEE-754-floating-point-numbers>View the format of IEEE 754 floating point numbers</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>9.1 (23)</td></tr>
<tr><td><a href=source-code/dynamic-allocation-multidimensional-arrays>Examples of dynamic multidimensional arrays</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>9.1 (25)</td></tr>
<tr><td><a href=source-code/thousand-separator-example>Simple example for using thousand separator (,)</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>9.0 (7)</td></tr>
<tr><td><a href=source-code/base-conversion-program>Conversions between number systems</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>9.0 (4)</td></tr>
<tr><td><a href=source-code/pascals-triangle>Pascals Triangle Using  Combination Function of Indices</a></td><td><a href=mailto:ashine@hotmail.com>SHINE  AIYYAPPAN</a>
 </td><td>C</td><td>ANSI</td><td>9.0 (3)</td></tr>
<tr><td><a href=source-code/c-linked-list>Simple linked list implementation</a></td><td>yzb3
 </td><td>C</td><td>ANSI</td><td>9.0 (5)</td></tr>
<tr><td><a href=source-code/hash-table-in-cplusplus>A simple example of hashtable</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>9.0 (10)</td></tr>
<tr><td><a href=source-code/templated-queue-class>Templated queue class</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>9.0 (18)</td></tr>
<tr><td><a href=source-code/failproof-xor-encryption-decryption>Failproof  xor (en/de)cryption</a></td><td>yzb3
 </td><td>C</td><td>ANSI</td><td>9 (20)</td></tr>
<tr><td><a href=source-code/double-linked-list-cplusplus>A simple double linked list using OOP techniques</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.9 (16)</td></tr>
<tr><td><a href=source-code/polymorphism-example>Example of polymorphism</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.9 (21)</td></tr>
<tr><td><a href=source-code/stack-with-linked-list>An example of simple stack using linked lists.</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.8 (6)</td></tr>
<tr><td><a href=source-code/initial-values-for-static-multidimensional-array>Initial values for static multidimensional array</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C or C++</td><td>ANSI</td><td>8.8 (20)</td></tr>
<tr><td><a href=source-code/size-storage-capacity-primitive-types>Find size and storage capacity of primitive data types</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.8 (19)</td></tr>
<tr><td><a href=source-code/templated-stack-class>Templated stack class </a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.8 (16)</td></tr>
<tr><td><a href=source-code/simple-swapping-heapsort>Simple swapping heapsort</a></td><td>yzb3
 </td><td>C or C++</td><td>ANSI</td><td>8.7 (21)</td></tr>
<tr><td><a href=source-code/useful-macros-functions-and-tricks>useful macros, functions and tricks</a></td><td>yzb3
 </td><td>C</td><td>ANSI</td><td>8.7 (13)</td></tr>
<tr><td><a href=source-code/binary-addition-using-stack-stl>binary addition using stack in STL</a></td><td><a href=mailto:get.anmolb@gmail.com>anmol</a>
 </td><td>C++</td><td>ANSI</td><td>8.7 (6)</td></tr>
<tr><td><a href=source-code/useful-c-string-functions>Useful string functions</a></td><td>yzb3
 </td><td>C</td><td>ANSI</td><td>8.6 (20)</td></tr>
<tr><td><a href=source-code/ascii-table-generator>The standard ASCII table generator.</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.5 (12)</td></tr>
<tr><td><a href=source-code/cplusplus-exception-handling-example-with-file-copy>An example of Exception Handling</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.5 (10)</td></tr>
<tr><td><a href=source-code/xor-encryption-with-keyfile>xor (en/de)cryption using a key file</a></td><td>yzb3
 </td><td>C</td><td>ANSI</td><td>8.5 (15)</td></tr>
<tr><td><a href=source-code/word-wrap-in-c>Word wrap function</a></td><td><a href=mailto:seanhubbard2k@gmail.com>Sean Hubbard</a>
 </td><td>C</td><td>ANSI</td><td>8.3 (19)</td></tr>
<tr><td><a href=source-code/example-same-variable-name-different-scopes>An example of using the same variable name in different scopes</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.2 (21)</td></tr>
<tr><td><a href=source-code/one-line-swap-of-integers>One line swap of integers</a></td><td><a href=mailto:abhilash@chintech.org>abhilash</a>
 </td><td>C or C++</td><td>ANSI</td><td>8.2 (35)</td></tr>
<tr><td><a href=source-code/priority-queue-with-linked-list>An example of simple priority queue using linked lists.</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.2 (10)</td></tr>
<tr><td><a href=source-code/pascals-triangle>Pascal's Triangle</a></td><td><a href=mailto:alkaki_ali2@yahoo.com>Ali Murad</a>
 </td><td>C++</td><td>ANSI</td><td>8.1 (21)</td></tr>
<tr><td><a href=source-code/shorter-version-gotoxy>Shorter version of gotoxy</a></td><td><a href=mailto:stenedjo@gmail.com>Nedeljko</a>
 </td><td>C</td><td>Linux</td><td>7.6 (15)</td></tr>
</table>
 
<a href=list.php?page=1&count=30>Next 30</a><br>
<br>
<a href=http://www.cprogramming.com/snippets/add.php>Add a snippet!</a>
<div id="footer" class="noprint">

<div id="social" style="margin-top:5px;height:23px;">
<table>
<tr>
<td> 
<div id="fb-root"></div>
<div id="fb-recommend" class="fb-like" data-send="false" data-width="120" data-height="21" data-layout="button_count" data-action="recommend"></div>
</td>
<td>
<a class="twitter-share-button" data-count="horizontal" data-via="alexallain"></a>
</td>
<td>
<div class="g-plusone" data-size="medium"></div>
</td>
</tr>
</table>
</div>

<div style="font-size:14px;padding:10px;margin-top:5px;margin-bottom:5px;">
<div style="width:400px;margin-top:5px">
<div style="float:left"><a href=http://www.cprogramming.com/c++book/?inl=ft-nhp><img src=http://www.cprogramming.com/c++book/small_3d.jpg border=0></a></div>Want to become a C++ programmer? The Cprogramming.com ebook, Jumping into C++, will walk you through it, step-by-step. <a href=http://www.cprogramming.com/c++book/?inl=ft-nhp>Get Jumping into C++ today!</a>
</div>
<div style="clear: both"></div>

<b>Popular pages</b>
<ul>
 <li><a href=http://www.cprogramming.com/begin.html>Exactly how to get started with C++ (or C) today</a> 
<li><a href=http://www.cprogramming.com/tutorial/c-tutorial.html>C Tutorial</a>
<li><a href=http://www.cprogramming.com/tutorial/c++-tutorial.html>C++ Tutorial</a>
<li><a href=http://www.cprogramming.com/how_to_learn_to_program.html>5 ways you can learn to program faster</a> 
<li><a href=http://www.cprogramming.com/beginner_programming_mistakes.html>The 5 Most Common Problems New Programmers Face</a>
<li><a href=http://www.cprogramming.com/code_blocks/>How to set up a compiler</a>
<li><a href=http://www.cprogramming.com/tutorial/common.html>8 Common programming Mistakes</a> 
<li><a href=http://www.cprogramming.com/c++11/what-is-c++0x.html>What is C++11?</a>
<li><a href=http://www.cprogramming.com/tutorial/game_programming/same_game_part1.html>How to make a game in 48 hours</a>
</ul>

<b>Recent additions</b> <a href="http://feeds2.feedburner.com/Cprogrammingcom" rel="alternate" type="application/rss+xml"><img src="http://www.feedburner.com/fb/images/pub/feed-icon16x16.png" alt="subscribe to a feed" style="border:0" width="16" height="16"></img></a>
<ul>
<li><a href=http://www.cprogramming.com/tutorial/shared-libraries-linux-gcc.html>How to create a shared library on Linux with GCC</a> - December 30, 2011</li>
<li> <a href="http://www.cprogramming.com/c++11/c++11-nullptr-strongly-typed-enum-class.html">Enum classes and nullptr in C++11</a> - November 27, 2011</li>
<li><a href="http://www.cprogramming.com/tutorial/computersciencetheory/hash-table.html">Learn about The Hash Table</a> - November 20, 2011</li>
<li><a href="http://www.cprogramming.com/c++11/rvalue-references-and-move-semantics-in-c++11.html">Rvalue References and Move Semantics in C++11</a> - November 13, 2011</li>
<li><a href="http://www.cprogramming.com/java/c-and-c++-for-java-programmers.html">C and C++ for Java Programmers</a> - November 5, 2011</li>
<li><a href="http://www.cprogramming.com/tutorial/c++-iostreams.html">A Gentle Introduction to C++ IO Streams</a> - October 10, 2011</li>
</ul>

</div>
<style type="text/css">
@import url(http://www.google.com/cse/api/branding.css);
</style>
<div class="cse-branding-bottom" style="background-color:#FFFFFF;color:#000000;width:50%; margin:auto">
  <div class="cse-branding-form">
    <form action="http://www.google.com/cse" id="cse-search-box">
      <div>
        <input type="hidden" name="cx" value="partner-pub-2560316224908115:0581759109" />
        <input type="hidden" name="ie" value="UTF-8" />
        <input type="text" name="q" size="55" />
        <input type="submit" name="sa" value="Search" />
      </div>
    </form>
  </div>
  <div class="cse-branding-logo">
    <img src="http://www.google.com/images/poweredby_transparent/poweredby_FFFFFF.gif" alt="Google" />
  </div>
  <div class="cse-branding-text">
    Custom Search
  </div>
</div>

<center>
<div style="margin-top:20px; margin-bottom: 20px">
<script type="text/javascript">
<!--
google_ad_client = "pub-2560316224908115";
/* link_ads_bottom */
google_ad_slot = "2258412831";
google_ad_width = 728;
google_ad_height = 15;
//-->
</script> 
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js"> </script> 
</div>
 
<script type="text/javascript" src="http://forms.aweber.com/form/12/618210012.js"></script>

<div class="footer-links" style="padding:10px">
<a href="http://www.cprogramming.com/advertising.html">Advertising</a> | <a href="http://www.cprogramming.com/privacy.html">Privacy policy</a> |
<a href="http://www.cprogramming.com/use.html">Copyright � 1997-2011 Cprogramming.com. All rights reserved.</a> | <a href=mailto:webmaster@cprogramming.com>webmaster@cprogramming.com</a>
</div>
</div>
</div>
</td>
    	


<td class="content noprint" valign="top" rowspan="1" bgcolor="#EBEBEB">
<div class="content2"><br><div class="verticalad">







<script type="text/javascript"><!--
        e9 = new Object();
    e9.size = "160x600,120x600";
//--></script>
<script type="text/javascript" src="http://tags.expo9.exponential.com/tags/Cprogrammingcom/ROS/tags.js"></script>



</div><br>

<style type="text/css">
.sidebar-box { width: 150px; margin-bottom:5px; }
</style>
    <div id="side-images">
        <div style="padding:5px;margin-top:5px">
            <div style="margin-bottom: 5px">
                <b>Popular pages</b>
            </div>
            <div>
                
                <!--http://www.flickr.com/photos/baslow/5620208/sizes/o/in/photostream/ -->
                <div class = "sidebar-box">
                    <a href=http://www.cprogramming.com/tutorial/c-tutorial.html>
                    <img src=http://static.cprogramming.com/main_images/footer/5620208_bff9c514e6_s.jpg border=0 height=75 width=75 alt="C tutorial">
                    <br>
                    C Tutorial
                    </a>
                </div>
                

                
                <!--http://www.flickr.com/photos/29233640@N07/2855530649/sizes/sq/in/photostream/-->
                <div class = "sidebar-box">
                    <a href=http://www.cprogramming.com/begin.html>
                    <img src=http://static.cprogramming.com/main_images/footer/2855530649_905f7862fd_s.jpg border=0 height=75 width=75 alt="Get started">
                    <br>
                    Exactly how to get started with C++ (or C) today</a>
                </div>
                

                
                <!--http://www.flickr.com/photos/mikecogh/6505012533/sizes/sq/in/photostream/-->
                <div class = "sidebar-box">
                    <a href=http://www.cprogramming.com/how_to_learn_to_program.html>
                    <img src=http://static.cprogramming.com/main_images/footer/6505012533_55c83fdfa0_s.jpg border=0 height=75 width=75 alt="Learn to program">
                    <br>
                    5 ways you can learn to program faster</a>
                </div>
                

                
                <div class = "sidebar-box">
                    <a href=http://www.cprogramming.com/tutorial/c++-tutorial.html>
                    <img src=http://static.cprogramming.com/main_images/footer/c++-img.png border=0 height=75 width=75 alt="C++ tutorial">
                    <br>
                    C++ Tutorial</a>
                </div>
                

                
                <!--http://www.flickr.com/photos/giopuo/3441263816/sizes/sq/in/photostream/-->
                <div class = "sidebar-box">
                    <a href=http://www.cprogramming.com/beginner_programming_mistakes.html>
                    <img src=http://static.cprogramming.com/main_images/footer/3441263816_95f132a884_s.jpg border=0 height=75 width=75 alt="Problems new programmers face">
                    <br>
                    The 5 Most Common Problems New Programmers Face</a>
                </div>
                

                
                <div class = "sidebar-box">
                   <a href=http://www.cprogramming.com/tutorial/game_programming/same_game_part1.html>
                    <img src=http://www.cprogramming.com/tutorial/game_programming/same_game_small.png border=0 height=42 width=42 alt="Learn to make a game">
                    <br>
                   How to make a game in 48 hours</a>
                </div>
                

                
                <div class = "sidebar-box">
                   <a href=http://www.cprogramming.com/tutorial/common.html>
                    <img src=http://static.cprogramming.com/main_images/footer/2291127824_087a497bea_s.jpg border=0 height=75 width=75 alt="Common problems">
                    <br>
                   8 Common Programming Mistakes</a>
                </div>
                

                
                <div class = "sidebar-box">
                   <a href=http://www.cprogramming.com/c++11/what-is-c++0x.html>
                    <img src=http://static.cprogramming.com/main_images/footer/c++11.png border=0 height=75 width=75 alt="C++11">
                    <br>
                   What is C++11?</a>
                </div>
                
            </div>
        </div>
        <div style="display:block">
            <a href=/image_credits.html>Image credits</a>
        </div>
    </div>
</div>
</td>  	

</tr>
</table>
</div>


<script>
(function(w, d, s) {
  var cur_url = window.location;
  var loc = cur_url;
  if ( /htm(l?)/.test( cur_url.pathname ) ) {
    loc = cur_url.protocol + "//" + cur_url.host + cur_url.pathname.replace( /\+/g, "%2b" );
  }
  d.getElementById( "fb-recommend" ).setAttribute( "data-href", loc );
  function go(){
    var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
          if (d.getElementById(id)) {return;}
          js = d.createElement(s); js.src = url; js.id = id;
          fjs.parentNode.insertBefore(js, fjs);
        };
    load('//connect.facebook.net/en_US/all.js#xfbml=1&channelUrl=http%3A%2F%2Fwww.cprogramming.com%2Ffb%2Fchannel.html', 'fbjssdk');
    load('https://apis.google.com/js/plusone.js', 'gplus1js');
    load('//platform.twitter.com/widgets.js', 'tweetjs');
  }
  if (w.addEventListener) { w.addEventListener("load", go, false); }
  else if (w.attachEvent) { w.attachEvent("onload",go); }
}(window, document, 'script'));
</script>


</body>
</html>

<script type="text/javascript" src="http://static.cprogramming.com/syntax-highlight/scripts/shCore.js"></script>
<script type="text/javascript" src="http://static.cprogramming.com/syntax-highlight/scripts/shBrushCpp.js"></script>
<script type="text/javascript">
         SyntaxHighlighter.all();
</script>



